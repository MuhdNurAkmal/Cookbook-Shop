﻿Public Class frm_menu_a181765
    Private Sub btn_productlist_Click(sender As Object, e As EventArgs) Handles btn_productlist.Click

        frm_productslist_a181765.Show()
        Me.Hide()

    End Sub

    Private Sub btn_customerslist_Click(sender As Object, e As EventArgs) Handles btn_customerslist.Click

        frm_customerslist_a181765.Show()
        Me.Hide()

    End Sub

    Private Sub btn_staffslist_Click(sender As Object, e As EventArgs) Handles btn_staffslist.Click

        frm_staffslist_a181765.Show()
        Me.Hide()

    End Sub

    Private Sub btn_orderslist_Click(sender As Object, e As EventArgs) Handles btn_orderslist.Click

        frm_orderslist_a181765.Show()
        Me.Hide()

    End Sub

    Private Sub btn_purchaseslist_Click(sender As Object, e As EventArgs) Handles btn_purchaseslist.Click

        frm_purchaseslist_a181765.Show()
        Me.Hide()

    End Sub

    Private Sub btn_exit_Click(sender As Object, e As EventArgs) Handles btn_exit.Click

        MsgBox("Thank you for visiting our shop, see you next time!", MsgBoxStyle.Information, "Exit Program")
        End

    End Sub

    Private Sub btn_catalog_Click(sender As Object, e As EventArgs) Handles btn_catalog.Click

        frm_cookbookcatalog_a181765.Show()
        Me.Hide()

    End Sub

    Private Sub frm_menu_a181765_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class