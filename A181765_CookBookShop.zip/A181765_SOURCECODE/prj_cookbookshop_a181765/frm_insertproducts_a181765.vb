﻿Public Class frm_insertproducts_a181765

    Dim defaultpicture As String = Application.StartupPath & "\pictures\nophoto.jpg"

    Private Sub frm_insertproducts_a181765_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        grd_products.DataSource = run_sql_query("SELECT * FROM TBL_PRODUCTS_A181765")

        txt_productid.Text = generate_id()

        grd_products.Columns(0).HeaderText = "Book ID"
        grd_products.Columns(1).HeaderText = "Book Title"
        grd_products.Columns(2).HeaderText = "Price (RM)"
        grd_products.Columns(3).HeaderText = "Author"
        grd_products.Columns(4).HeaderText = "Publisher"
        grd_products.Columns(5).HeaderText = "Number of Pages"
        grd_products.Columns(6).HeaderText = "ISBN"

        txt_picture.Text = defaultpicture
        pic_product.BackgroundImage = Image.FromFile(defaultpicture)

        refresh_grid()

    End Sub

    Private Sub refresh_grid()

        Dim mysql As String = "SELECT * FROM TBL_PRODUCTS_A181765"

        Dim mydatatable As New DataTable

        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)

        myreader.Fill(mydatatable)

        grd_products.DataSource = mydatatable

    End Sub

    Private Function generate_id() As String

        Dim lastproduct As String = run_sql_query("SELECT MAX(FLD_PRODUCT_ID) AS LASTPRODUCT FROM TBL_PRODUCTS_A181765").Rows(0).Item("LASTPRODUCT")

        Dim newproduct As String = "CB" & Mid(lastproduct, 3) + 1

        Return newproduct

    End Function

    Private Sub btn_insert_Click(sender As Object, e As EventArgs) Handles btn_insert.Click

        Dim mysql As String = "INSERT INTO TBL_PRODUCTS_A181765 VALUES ('" & txt_productid.Text & "', '" & txt_name.Text & "','" & txt_price.Text & "','" &
                              txt_author.Text & "','" & txt_publisher.Text & "','" & txt_numpages.Text & "','" & txt_isbn.Text & "')"

        Dim mywriter As New OleDb.OleDbCommand(mysql, myconnection2)

        Try

            mywriter.Connection.Open()
            mywriter.ExecuteNonQuery()
            mywriter.Connection.Close()

            My.Computer.FileSystem.CopyFile(txt_picture.Text, "pictures\" & txt_productid.Text & ".jpg")

            grd_products.DataSource = run_sql_query("SELECT * FROM TBL_PRODUCTS_A181765")

            txt_productid.Text = generate_id()
            txt_name.Text = ""
            txt_price.Text = ""
            txt_author.Text = ""
            txt_publisher.Text = ""
            txt_numpages.Text = ""
            txt_isbn.Text = ""
            txt_picture.Text = defaultpicture
            pic_product.BackgroundImage = Image.FromFile(defaultpicture)

        Catch ex As Exception

            Beep()
            MsgBox("There is a mistake in the data you entered, as shown below" & vbCrLf & vbCrLf & ex.Message)

            mywriter.Connection.Close()

        End Try

        refresh_grid()

    End Sub

    Private Sub btn_picture_Click(sender As Object, e As EventArgs) Handles btn_picture.Click

        Dim mydesktop As String = My.Computer.FileSystem.SpecialDirectories.Desktop

        OpenFileDialog1.InitialDirectory = mydesktop
        OpenFileDialog1.FileName = ""
        OpenFileDialog1.Filter = "JPG files (*.jpg) | *.jpg"
        OpenFileDialog1.ShowDialog()

        pic_product.BackgroundImage = Image.FromFile(OpenFileDialog1.FileName)
        txt_picture.Text = OpenFileDialog1.FileName

        refresh_grid()

    End Sub

    Private Sub btn_mainmenu_Click(sender As Object, e As EventArgs) Handles btn_mainmenu.Click

        frm_productslist_a181765.Show()
        Me.Hide()

    End Sub
End Class