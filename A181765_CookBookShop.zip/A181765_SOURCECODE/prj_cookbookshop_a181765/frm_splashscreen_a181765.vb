﻿Public Class frm_splashscreen_a181765
    Private Sub btn_start_Click(sender As Object, e As EventArgs) Handles btn_start.Click

        frm_menu_a181765.Show()
        Me.Hide()

    End Sub
End Class