﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_insertproducts_a181765
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_insertproducts_a181765))
        Me.lbl_title = New System.Windows.Forms.Label()
        Me.grd_products = New System.Windows.Forms.DataGridView()
        Me.txt_productid = New System.Windows.Forms.TextBox()
        Me.txt_name = New System.Windows.Forms.TextBox()
        Me.txt_price = New System.Windows.Forms.TextBox()
        Me.txt_author = New System.Windows.Forms.TextBox()
        Me.txt_publisher = New System.Windows.Forms.TextBox()
        Me.txt_numpages = New System.Windows.Forms.TextBox()
        Me.txt_isbn = New System.Windows.Forms.TextBox()
        Me.lbl_productid = New System.Windows.Forms.Label()
        Me.lbl_name = New System.Windows.Forms.Label()
        Me.lbl_price = New System.Windows.Forms.Label()
        Me.lbl_author = New System.Windows.Forms.Label()
        Me.lbl_publisher = New System.Windows.Forms.Label()
        Me.lbl_pages = New System.Windows.Forms.Label()
        Me.lbl_isbn = New System.Windows.Forms.Label()
        Me.lbl_instruction = New System.Windows.Forms.Label()
        Me.btn_insert = New System.Windows.Forms.Button()
        Me.txt_picture = New System.Windows.Forms.TextBox()
        Me.pic_product = New System.Windows.Forms.PictureBox()
        Me.lbl_uploadpics = New System.Windows.Forms.Label()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.btn_picture = New System.Windows.Forms.Button()
        Me.btn_mainmenu = New System.Windows.Forms.Button()
        CType(Me.grd_products, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_product, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lbl_title
        '
        Me.lbl_title.AutoSize = True
        Me.lbl_title.Font = New System.Drawing.Font("Motion Picture Personal Use ", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title.Location = New System.Drawing.Point(267, 21)
        Me.lbl_title.Name = "lbl_title"
        Me.lbl_title.Size = New System.Drawing.Size(290, 55)
        Me.lbl_title.TabIndex = 0
        Me.lbl_title.Text = "Product Registration"
        '
        'grd_products
        '
        Me.grd_products.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.grd_products.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.grd_products.BackgroundColor = System.Drawing.Color.White
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.SkyBlue
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd_products.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grd_products.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd_products.DefaultCellStyle = DataGridViewCellStyle2
        Me.grd_products.EnableHeadersVisualStyles = False
        Me.grd_products.GridColor = System.Drawing.Color.Black
        Me.grd_products.Location = New System.Drawing.Point(16, 96)
        Me.grd_products.Name = "grd_products"
        Me.grd_products.Size = New System.Drawing.Size(772, 206)
        Me.grd_products.TabIndex = 1
        '
        'txt_productid
        '
        Me.txt_productid.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_productid.Location = New System.Drawing.Point(294, 364)
        Me.txt_productid.Name = "txt_productid"
        Me.txt_productid.Size = New System.Drawing.Size(474, 22)
        Me.txt_productid.TabIndex = 2
        '
        'txt_name
        '
        Me.txt_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_name.Location = New System.Drawing.Point(294, 393)
        Me.txt_name.Multiline = True
        Me.txt_name.Name = "txt_name"
        Me.txt_name.Size = New System.Drawing.Size(474, 53)
        Me.txt_name.TabIndex = 3
        '
        'txt_price
        '
        Me.txt_price.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_price.Location = New System.Drawing.Point(294, 455)
        Me.txt_price.Name = "txt_price"
        Me.txt_price.Size = New System.Drawing.Size(474, 22)
        Me.txt_price.TabIndex = 4
        '
        'txt_author
        '
        Me.txt_author.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_author.Location = New System.Drawing.Point(294, 488)
        Me.txt_author.Name = "txt_author"
        Me.txt_author.Size = New System.Drawing.Size(474, 22)
        Me.txt_author.TabIndex = 5
        '
        'txt_publisher
        '
        Me.txt_publisher.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_publisher.Location = New System.Drawing.Point(294, 519)
        Me.txt_publisher.Multiline = True
        Me.txt_publisher.Name = "txt_publisher"
        Me.txt_publisher.Size = New System.Drawing.Size(474, 43)
        Me.txt_publisher.TabIndex = 6
        '
        'txt_numpages
        '
        Me.txt_numpages.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_numpages.Location = New System.Drawing.Point(294, 571)
        Me.txt_numpages.Name = "txt_numpages"
        Me.txt_numpages.Size = New System.Drawing.Size(474, 22)
        Me.txt_numpages.TabIndex = 7
        '
        'txt_isbn
        '
        Me.txt_isbn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_isbn.Location = New System.Drawing.Point(294, 605)
        Me.txt_isbn.Name = "txt_isbn"
        Me.txt_isbn.Size = New System.Drawing.Size(474, 22)
        Me.txt_isbn.TabIndex = 8
        '
        'lbl_productid
        '
        Me.lbl_productid.AutoSize = True
        Me.lbl_productid.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_productid.Location = New System.Drawing.Point(196, 367)
        Me.lbl_productid.Name = "lbl_productid"
        Me.lbl_productid.Size = New System.Drawing.Size(62, 16)
        Me.lbl_productid.TabIndex = 9
        Me.lbl_productid.Text = "Book ID :"
        '
        'lbl_name
        '
        Me.lbl_name.AutoSize = True
        Me.lbl_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_name.Location = New System.Drawing.Point(196, 414)
        Me.lbl_name.Name = "lbl_name"
        Me.lbl_name.Size = New System.Drawing.Size(75, 16)
        Me.lbl_name.TabIndex = 10
        Me.lbl_name.Text = "Book Title :"
        '
        'lbl_price
        '
        Me.lbl_price.AutoSize = True
        Me.lbl_price.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_price.Location = New System.Drawing.Point(196, 458)
        Me.lbl_price.Name = "lbl_price"
        Me.lbl_price.Size = New System.Drawing.Size(45, 16)
        Me.lbl_price.TabIndex = 11
        Me.lbl_price.Text = "Price :"
        '
        'lbl_author
        '
        Me.lbl_author.AutoSize = True
        Me.lbl_author.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_author.Location = New System.Drawing.Point(196, 491)
        Me.lbl_author.Name = "lbl_author"
        Me.lbl_author.Size = New System.Drawing.Size(52, 16)
        Me.lbl_author.TabIndex = 12
        Me.lbl_author.Text = "Author :"
        '
        'lbl_publisher
        '
        Me.lbl_publisher.AutoSize = True
        Me.lbl_publisher.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_publisher.Location = New System.Drawing.Point(196, 533)
        Me.lbl_publisher.Name = "lbl_publisher"
        Me.lbl_publisher.Size = New System.Drawing.Size(70, 16)
        Me.lbl_publisher.TabIndex = 13
        Me.lbl_publisher.Text = "Publisher :"
        '
        'lbl_pages
        '
        Me.lbl_pages.AutoSize = True
        Me.lbl_pages.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_pages.Location = New System.Drawing.Point(196, 574)
        Me.lbl_pages.Name = "lbl_pages"
        Me.lbl_pages.Size = New System.Drawing.Size(92, 16)
        Me.lbl_pages.TabIndex = 14
        Me.lbl_pages.Text = "No. of Pages :"
        '
        'lbl_isbn
        '
        Me.lbl_isbn.AutoSize = True
        Me.lbl_isbn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_isbn.Location = New System.Drawing.Point(196, 608)
        Me.lbl_isbn.Name = "lbl_isbn"
        Me.lbl_isbn.Size = New System.Drawing.Size(45, 16)
        Me.lbl_isbn.TabIndex = 15
        Me.lbl_isbn.Text = "ISBN :"
        '
        'lbl_instruction
        '
        Me.lbl_instruction.AutoSize = True
        Me.lbl_instruction.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, CType(((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic) _
                Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_instruction.Location = New System.Drawing.Point(17, 317)
        Me.lbl_instruction.Name = "lbl_instruction"
        Me.lbl_instruction.Size = New System.Drawing.Size(394, 18)
        Me.lbl_instruction.TabIndex = 16
        Me.lbl_instruction.Text = "Please fill in the book details in the space provided."
        '
        'btn_insert
        '
        Me.btn_insert.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btn_insert.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_insert.Location = New System.Drawing.Point(678, 642)
        Me.btn_insert.Name = "btn_insert"
        Me.btn_insert.Size = New System.Drawing.Size(90, 35)
        Me.btn_insert.TabIndex = 17
        Me.btn_insert.Text = "INSERT"
        Me.btn_insert.UseVisualStyleBackColor = False
        '
        'txt_picture
        '
        Me.txt_picture.Location = New System.Drawing.Point(20, 551)
        Me.txt_picture.Multiline = True
        Me.txt_picture.Name = "txt_picture"
        Me.txt_picture.Size = New System.Drawing.Size(153, 35)
        Me.txt_picture.TabIndex = 18
        '
        'pic_product
        '
        Me.pic_product.BackColor = System.Drawing.Color.White
        Me.pic_product.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pic_product.Location = New System.Drawing.Point(43, 404)
        Me.pic_product.Name = "pic_product"
        Me.pic_product.Size = New System.Drawing.Size(109, 141)
        Me.pic_product.TabIndex = 19
        Me.pic_product.TabStop = False
        '
        'lbl_uploadpics
        '
        Me.lbl_uploadpics.AutoSize = True
        Me.lbl_uploadpics.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_uploadpics.Location = New System.Drawing.Point(23, 364)
        Me.lbl_uploadpics.Name = "lbl_uploadpics"
        Me.lbl_uploadpics.Size = New System.Drawing.Size(150, 32)
        Me.lbl_uploadpics.TabIndex = 20
        Me.lbl_uploadpics.Text = "Please upload a picture" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "of the book :"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'btn_picture
        '
        Me.btn_picture.Location = New System.Drawing.Point(43, 592)
        Me.btn_picture.Name = "btn_picture"
        Me.btn_picture.Size = New System.Drawing.Size(109, 35)
        Me.btn_picture.TabIndex = 21
        Me.btn_picture.Text = "Choose Picture"
        Me.btn_picture.UseVisualStyleBackColor = True
        '
        'btn_mainmenu
        '
        Me.btn_mainmenu.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btn_mainmenu.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_mainmenu.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btn_mainmenu.Location = New System.Drawing.Point(21, 21)
        Me.btn_mainmenu.Name = "btn_mainmenu"
        Me.btn_mainmenu.Size = New System.Drawing.Size(90, 35)
        Me.btn_mainmenu.TabIndex = 23
        Me.btn_mainmenu.Text = "BACK"
        Me.btn_mainmenu.UseVisualStyleBackColor = False
        '
        'frm_insertproducts_a181765
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(800, 694)
        Me.Controls.Add(Me.btn_mainmenu)
        Me.Controls.Add(Me.btn_picture)
        Me.Controls.Add(Me.lbl_uploadpics)
        Me.Controls.Add(Me.pic_product)
        Me.Controls.Add(Me.txt_picture)
        Me.Controls.Add(Me.btn_insert)
        Me.Controls.Add(Me.lbl_instruction)
        Me.Controls.Add(Me.lbl_isbn)
        Me.Controls.Add(Me.lbl_pages)
        Me.Controls.Add(Me.lbl_publisher)
        Me.Controls.Add(Me.lbl_author)
        Me.Controls.Add(Me.lbl_price)
        Me.Controls.Add(Me.lbl_name)
        Me.Controls.Add(Me.lbl_productid)
        Me.Controls.Add(Me.txt_isbn)
        Me.Controls.Add(Me.txt_numpages)
        Me.Controls.Add(Me.txt_publisher)
        Me.Controls.Add(Me.txt_author)
        Me.Controls.Add(Me.txt_price)
        Me.Controls.Add(Me.txt_name)
        Me.Controls.Add(Me.txt_productid)
        Me.Controls.Add(Me.grd_products)
        Me.Controls.Add(Me.lbl_title)
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frm_insertproducts_a181765"
        Me.Text = "Add New Product"
        CType(Me.grd_products, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_product, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl_title As Label
    Friend WithEvents grd_products As DataGridView
    Friend WithEvents txt_productid As TextBox
    Friend WithEvents txt_name As TextBox
    Friend WithEvents txt_price As TextBox
    Friend WithEvents txt_author As TextBox
    Friend WithEvents txt_publisher As TextBox
    Friend WithEvents txt_numpages As TextBox
    Friend WithEvents txt_isbn As TextBox
    Friend WithEvents lbl_productid As Label
    Friend WithEvents lbl_name As Label
    Friend WithEvents lbl_price As Label
    Friend WithEvents lbl_author As Label
    Friend WithEvents lbl_publisher As Label
    Friend WithEvents lbl_pages As Label
    Friend WithEvents lbl_isbn As Label
    Friend WithEvents lbl_instruction As Label
    Friend WithEvents btn_insert As Button
    Friend WithEvents txt_picture As TextBox
    Friend WithEvents pic_product As PictureBox
    Friend WithEvents lbl_uploadpics As Label
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents btn_picture As Button
    Friend WithEvents btn_mainmenu As Button
End Class
