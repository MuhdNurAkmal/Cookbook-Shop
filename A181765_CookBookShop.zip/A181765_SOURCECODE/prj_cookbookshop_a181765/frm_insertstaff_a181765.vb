﻿Public Class frm_insertstaff_a181765
    Private Sub frm_insertstaff_a181765_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        grd_staff.DataSource = run_sql_query("SELECT * FROM TBL_STAFFS_A181765")

        txt_staffid.Text = generate_id()

        grd_staff.Columns(0).HeaderText = "Staff ID"
        grd_staff.Columns(1).HeaderText = "Staff Name"
        grd_staff.Columns(2).HeaderText = "Phone Number"

        refresh_grid()

    End Sub

    Private Sub refresh_grid()

        Dim mysql As String = "SELECT * FROM TBL_STAFFS_A181765"

        Dim mydatatable As New DataTable

        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)

        myreader.Fill(mydatatable)

        grd_staff.DataSource = mydatatable

    End Sub
    Private Function generate_id() As String

        Dim laststaff As String = run_sql_query("SELECT MAX(FLD_STAFF_ID) AS LASTSTAFF FROM TBL_STAFFS_A181765").Rows(0).Item("LASTSTAFF")

        Dim newstaff As String = "S0" & Mid(laststaff, 2) + 1

        Return newstaff

    End Function

    Private Sub btn_insert_Click(sender As Object, e As EventArgs) Handles btn_insert.Click

        Dim mysql As String = "INSERT INTO TBL_STAFFS_A181765 VALUES ('" & txt_staffid.Text & "', '" & txt_name.Text & "','" & txt_phone.Text & "')"

        Dim mywriter As New OleDb.OleDbCommand(mysql, myconnection2)

        Try

            mywriter.Connection.Open()
            mywriter.ExecuteNonQuery()
            mywriter.Connection.Close()

            grd_staff.DataSource = run_sql_query("SELECT * FROM TBL_STAFFS_A181765")

            txt_staffid.Text = generate_id()
            txt_name.Text = ""
            txt_phone.Text = ""

        Catch ex As Exception

            Beep()
            MsgBox("There is a mistake in the data you entered, as shown below" & vbCrLf & vbCrLf & ex.Message)

            mywriter.Connection.Close()

        End Try

        refresh_grid()

    End Sub

    Private Sub btn_mainmenu_Click(sender As Object, e As EventArgs) Handles btn_mainmenu.Click

        frm_staffslist_a181765.Show()
        Me.Hide()

    End Sub
End Class