﻿Public Class frm_customerslist_a181765
    Private Sub frm_customerslist_a181765_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim mysql As String = "SELECT * FROM TBL_CUSTOMERS_A181765"

        Dim mydatatable As New DataTable

        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)

        myreader.Fill(mydatatable)

        grd_customers.DataSource = mydatatable

        grd_customers.Columns(0).HeaderText = "Customer ID"
        grd_customers.Columns(1).HeaderText = "Customer Name"
        grd_customers.Columns(2).HeaderText = "Home Address"
        grd_customers.Columns(3).HeaderText = "Phone Number"

        refresh_grid()

    End Sub

    Private Sub refresh_grid()

        Dim mysql As String = "SELECT * FROM TBL_CUSTOMERS_A181765"

        Dim mydatatable As New DataTable

        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)

        myreader.Fill(mydatatable)

        grd_customers.DataSource = mydatatable

    End Sub

    Private Sub btn_back_Click(sender As Object, e As EventArgs) Handles btn_back.Click

        frm_menu_a181765.Show()
        Me.Hide()

    End Sub

    Private Sub btn_addcust_Click(sender As Object, e As EventArgs) Handles btn_addcust.Click

        frm_insertcustomer_a181765.Show()
        Me.Hide()

    End Sub

    Private Sub btn_editcust_Click(sender As Object, e As EventArgs) Handles btn_editcust.Click

        frm_updatecustomer_a181765.Show()
        Me.Hide()

    End Sub
End Class