﻿Public Class frm_makeorders_a181765

    Dim current_id As String
    Dim current_order As String

    Private Sub frm_makeorders_a181765_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'code2 kecil
        refresh_grid()
        clear_field()
        txt_quantity.Text = "1"
        txt_orderid.Text = generate_id()
        Dim current_date As String = Date.Now.ToString("dd MMM yyyy")
        txt_orderdate.Text = current_date

        'masukkan productID dalam listView
        Dim mysql As String = "SELECT FLD_PRODUCT_ID FROM TBL_PRODUCTS_A181765"
        Dim mydatatable As New DataTable
        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)
        myreader.Fill(mydatatable)
        lst_productid.DataSource = mydatatable
        lst_productid.DisplayMember = "FLD_PRODUCT_ID"
        refresh_productlist(lst_productid.Text)

        'masukkan custID dalam combobox
        Dim mysql2 As String = "SELECT FLD_CUST_ID FROM TBL_CUSTOMERS_A181765"
        Dim mydatatable2 As New DataTable
        Dim myreader2 As New OleDb.OleDbDataAdapter(mysql2, myconnection)
        myreader2.Fill(mydatatable2)
        cmb_custid.DataSource = mydatatable2
        cmb_custid.DisplayMember = "FLD_CUST_ID"
        refresh_custdetails(cmb_custid.Text)

        'masukkan staffID dalam combobox
        Dim mysql3 As String = "SELECT FLD_STAFF_ID FROM TBL_STAFFS_A181765"
        Dim mydatatable3 As New DataTable
        Dim myreader3 As New OleDb.OleDbDataAdapter(mysql3, myconnection)
        myreader3.Fill(mydatatable3)
        cmb_staffid.DataSource = mydatatable3
        cmb_staffid.DisplayMember = "FLD_STAFF_ID"
        refresh_staffdetails(cmb_staffid.Text)

    End Sub

    'Auto generate order ID
    Private Function generate_id() As String

        Dim lastproduct As String = run_sql_query("SELECT MAX(FLD_ORDER_ID) AS LASTPRODUCT FROM TBL_ORDERS_A181765").Rows(0).Item("LASTPRODUCT")
        Dim newproduct As String = "OR" & Mid(lastproduct, 3) + 1
        Return newproduct

    End Function

    'Purchase section
    Private Sub refresh_grid()

        Dim mysql As String = "SELECT TBL_PURCHASES_A181765.FLD_PRODUCT_ID, TBL_PRODUCTS_A181765.FLD_PRODUCT_NAME, TBL_PURCHASES_A181765.FLD_PRICE, TBL_PURCHASES_A181765.FLD_QUANTITY, [TBL_PURCHASES_A181765]![FLD_PRICE]*[TBL_PURCHASES_A181765]![FLD_QUANTITY] AS Subtotal" _
                            & " FROM TBL_ORDERS_A181765 INNER JOIN (TBL_PRODUCTS_A181765 INNER JOIN TBL_PURCHASES_A181765 ON TBL_PRODUCTS_A181765.FLD_PRODUCT_ID = TBL_PURCHASES_A181765.FLD_PRODUCT_ID) ON TBL_ORDERS_A181765.FLD_ORDER_ID = TBL_PURCHASES_A181765.FLD_ORDER_ID" _
                            & " WHERE (((TBL_PURCHASES_A181765.FLD_ORDER_ID)='" & txt_orderid.Text & "'))"
        Dim mydatatable As New DataTable
        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)
        myreader.Fill(mydatatable)
        grd_purchases.DataSource = mydatatable
        grd_purchases.Columns(0).HeaderText = "Book ID"
        grd_purchases.Columns(1).HeaderText = "Book Title"
        grd_purchases.Columns(2).HeaderText = "Price"
        grd_purchases.Columns(3).HeaderText = "Quantity"


    End Sub

    'ListView Product section
    Private Sub refresh_productlist(productid As String)

        Dim mysql As String = "Select * FROM TBL_PRODUCTS_A181765 WHERE FLD_PRODUCT_ID='" & productid & "'"
        Dim mydatatable As New DataTable
        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)
        myreader.Fill(mydatatable)
        txt_bookid.Text = mydatatable.Rows(0).Item("FLD_PRODUCT_ID")
        txt_booktitle.Text = mydatatable.Rows(0).Item("FLD_PRODUCT_NAME")
        txt_bookprice.Text = "RM " & mydatatable.Rows(0).Item("FLD_PRICE")
        txt_bookauthor.Text = mydatatable.Rows(0).Item("FLD_AUTHOR")
        txt_publisher.Text = mydatatable.Rows(0).Item("FLD_PUBLISHER")
        txt_numpage.Text = mydatatable.Rows(0).Item("FLD_NUM_PAGES")
        txt_isbn.Text = mydatatable.Rows(0).Item("FLD_ISBN")
        pic_bookpics.BackgroundImage = Image.FromFile("pictures/" & txt_bookid.Text & ".jpg")

    End Sub
    Private Sub lst_productid_MouseClick(sender As Object, e As MouseEventArgs) Handles lst_productid.MouseClick

        refresh_productlist(lst_productid.Text)
        txt_quantity.Text = "1"

    End Sub

    'Customer section
    Private Sub refresh_custdetails(custid As String)

        Dim mysql As String = "SELECT * FROM TBL_CUSTOMERS_A181765 WHERE FLD_CUST_ID='" & custid & "'"
        Dim mydatatable As New DataTable
        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)
        myreader.Fill(mydatatable)
        If mydatatable.Rows.Count > 0 Then
            txt_custname.Text = mydatatable.Rows(0).Item("FLD_CUST_NAME")
            txt_address.Text = mydatatable.Rows(0).Item("FLD_CUST_ADDRESS")
            txt_phoneno.Text = mydatatable.Rows(0).Item("FLD_CUST_PHONENO")
        End If

    End Sub
    Private Sub cmb_custid_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmb_custid.SelectedIndexChanged

        refresh_custdetails(cmb_custid.Text)

    End Sub

    'Staff section
    Private Sub refresh_staffdetails(staffid As String)

        Dim mysql As String = "SELECT * FROM TBL_STAFFS_A181765 WHERE FLD_STAFF_ID='" & staffid & "'"
        Dim mydatatable As New DataTable
        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)
        myreader.Fill(mydatatable)
        If mydatatable.Rows.Count > 0 Then
            txt_staffname.Text = mydatatable.Rows(0).Item("FLD_STAFF_NAME")
            txt_staffphoneno.Text = mydatatable.Rows(0).Item("FLD_PHONE_NO")
        End If

    End Sub
    Private Sub cmb_staffid_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmb_staffid.SelectedIndexChanged

        refresh_staffdetails(cmb_staffid.Text)

    End Sub

    'Add to Cart button
    Private Sub btn_addtocart_Click(sender As Object, e As EventArgs) Handles btn_addtocart.Click

        'Add order details into database
        Dim order_date As String = "INSERT INTO TBL_ORDERS_A181765 VALUES ('" & txt_orderid.Text & "', '" & txt_orderdate.Text & "', '" & cmb_staffid.Text & "')"
        Dim mywriter2 As New OleDb.OleDbCommand(order_date, myconnection2)
        Try
            mywriter2.Connection.Open()
            mywriter2.ExecuteNonQuery()
            mywriter2.Connection.Close()
        Catch ex As Exception
            mywriter2.Connection.Close()
        End Try

        'Add product ordered into database
        Dim mysql As String = "INSERT INTO TBL_PURCHASES_A181765 VALUES ('" & txt_orderid.Text & "', '" & txt_bookid.Text & "', '" & txt_bookprice.Text & "', " & txt_quantity.Text & ", '" & cmb_custid.Text & "')"
        Dim mywriter As New OleDb.OleDbCommand(mysql, myconnection2)
        Try
            mywriter.Connection.Open()
            mywriter.ExecuteNonQuery()
            mywriter.Connection.Close()
            grd_purchases.DataSource = run_sql_query("SELECT TBL_PURCHASES_A181765.FLD_PRODUCT_ID, TBL_PRODUCTS_A181765.FLD_PRODUCT_NAME, TBL_PURCHASES_A181765.FLD_PRICE, TBL_PURCHASES_A181765.FLD_QUANTITY, [TBL_PURCHASES_A181765]![FLD_PRICE]*[TBL_PURCHASES_A181765]![FLD_QUANTITY] AS Subtotal" _
                            & " FROM TBL_ORDERS_A181765 INNER JOIN (TBL_PRODUCTS_A181765 INNER JOIN TBL_PURCHASES_A181765 ON TBL_PRODUCTS_A181765.FLD_PRODUCT_ID = TBL_PURCHASES_A181765.FLD_PRODUCT_ID) ON TBL_ORDERS_A181765.FLD_ORDER_ID = TBL_PURCHASES_A181765.FLD_ORDER_ID" _
                            & " WHERE (((TBL_PURCHASES_A181765.FLD_ORDER_ID)='" & txt_orderid.Text & "'))")

            Dim sum_subtotal As Decimal
            For Each row As DataGridViewRow In grd_purchases.Rows
                sum_subtotal += row.Cells(4).Value
            Next
            txt_total.Text = "RM" & sum_subtotal

        Catch ex As Exception
            mywriter.Connection.Close()
        End Try

        refresh_grid()

    End Sub

    'increase and decrease quantity button
    Private Sub btn_addqtty_Click(sender As Object, e As EventArgs) Handles btn_addqtty.Click
        Dim addqtty As Double = txt_quantity.Text
        txt_quantity.Text = (addqtty + 1).ToString
    End Sub
    Private Sub btn_minusqtty_Click(sender As Object, e As EventArgs) Handles btn_minusqtty.Click
        Dim addqtty As Double = txt_quantity.Text
        If addqtty < 0 Then
            txt_quantity.Text = "0"
        Else
            txt_quantity.Text = (addqtty - 1).ToString
        End If
    End Sub

    'remove item from table
    Private Sub get_current_id()

        Dim current_row As Integer = grd_purchases.CurrentRow.Index
        current_id = grd_purchases(0, current_row).Value

    End Sub
    Private Sub grd_purchases_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grd_purchases.CellClick
        get_current_id()
    End Sub
    Private Sub btn_remove_Click(sender As Object, e As EventArgs) Handles btn_remove.Click

        Dim delete_confirmation = MsgBox("Are you sure you would like to delete this item ?", MsgBoxStyle.YesNo)
        If delete_confirmation = MsgBoxResult.Yes Then
            run_sql_command("DELETE TBL_PURCHASES_A181765.FLD_ORDER_ID, TBL_PURCHASES_A181765.FLD_PRODUCT_ID, TBL_PURCHASES_A181765.FLD_PRICE, TBL_PURCHASES_A181765.FLD_QUANTITY, TBL_PURCHASES_A181765.FLD_CUST_ID" _
                            & " FROM TBL_PURCHASES_A181765" _
                            & " WHERE (((TBL_PURCHASES_A181765.FLD_ORDER_ID)='" & txt_orderid.Text & "') AND ((TBL_PURCHASES_A181765.FLD_PRODUCT_ID)='" & current_id & "'))")
            Beep()
            refresh_grid()
        End If

    End Sub

    'reset all
    Private Sub clear_field()

        'book section
        txt_bookid.Text = ""
        txt_booktitle.Text = ""
        txt_bookprice.Text = ""
        txt_bookauthor.Text = ""
        txt_publisher.Text = ""
        txt_numpage.Text = ""
        txt_isbn.Text = ""

        'customer section
        txt_custname.Text = ""
        txt_address.Text = ""
        txt_phoneno.Text = ""

        'staff section
        txt_staffname.Text = ""
        txt_staffphoneno.Text = ""

    End Sub
    Private Sub btn_purchases_Click(sender As Object, e As EventArgs) Handles btn_purchases.Click

        MsgBox("You have successfully order your books. Thank you for buying", MsgBoxStyle.Information, "Order Received")
        Dim current_date As String = Date.Now.ToString("dd MMM yyyy")
        txt_orderdate.Text = current_date
        txt_orderid.Text = generate_id()
        clear_field()
        refresh_grid()

    End Sub

    Private Sub btn_back_Click(sender As Object, e As EventArgs) Handles btn_back.Click

        frm_orderslist_a181765.Show()
        Me.Hide()

    End Sub
End Class