﻿Public Class frm_cookbookcatalog_a181765
    Private Sub frm_cookbookcatalog_a181765_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim mysql As String = "SELECT FLD_PRODUCT_ID FROM TBL_PRODUCTS_A181765"

        Dim mydatatable As New DataTable

        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)

        myreader.Fill(mydatatable)

        lst_productID.DataSource = mydatatable
        lst_productID.DisplayMember = "FLD_PRODUCT_ID"

        refresh_text(lst_productID.Text)

    End Sub

    Private Sub refresh_text(productid As String)

        Dim mysql As String = "SELECT * FROM TBL_PRODUCTS_A181765 WHERE FLD_PRODUCT_ID='" & productid & "'"

        Dim mydatable As New DataTable

        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)

        myreader.Fill(mydatable)

        txt_productID.Text = mydatable.Rows(0).Item("FLD_PRODUCT_ID")
        txt_bookname.Text = mydatable.Rows(0).Item("FLD_PRODUCT_NAME")
        txt_price.Text = "RM " & mydatable.Rows(0).Item("FLD_PRICE")
        txt_author.Text = mydatable.Rows(0).Item("FLD_AUTHOR")
        txt_publisher.Text = mydatable.Rows(0).Item("FLD_PUBLISHER")
        txt_pages.Text = mydatable.Rows(0).Item("FLD_NUM_PAGES")
        txt_isbn.Text = mydatable.Rows(0).Item("FLD_ISBN")

        pic_book.BackgroundImage = Image.FromFile("pictures/" & txt_productID.Text & ".jpg")

    End Sub

    Private Sub lst_productID_MouseClick(sender As Object, e As MouseEventArgs) Handles lst_productID.MouseClick

        refresh_text(lst_productID.Text)

    End Sub

    Private Sub btn_mainmenu_Click(sender As Object, e As EventArgs) Handles btn_mainmenu.Click

        frm_menu_a181765.Show()
        Me.Hide()

    End Sub
End Class