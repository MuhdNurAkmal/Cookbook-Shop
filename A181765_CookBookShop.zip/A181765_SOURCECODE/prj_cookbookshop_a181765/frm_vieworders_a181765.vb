﻿Public Class frm_vieworders_a181765

    Dim current_id As String

    Private Sub frm_vieworders_a181765_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'gridview all orders
        Dim mysql As String = "SELECT FLD_ORDER_ID, FLD_ORDER_DATE FROM TBL_ORDERS_A181765"
        Dim mydatatable As New DataTable
        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)
        myreader.Fill(mydatatable)
        grd_orderslist.DataSource = mydatatable
        grd_orderslist.Columns(0).HeaderText = "Order ID"
        grd_orderslist.Columns(1).HeaderText = "Order Date"

        refresh_grid()

    End Sub

    Private Sub refresh_grid()

        Dim mysql As String = "SELECT FLD_ORDER_ID, FLD_ORDER_DATE FROM TBL_ORDERS_A181765"
        Dim mydatatable As New DataTable
        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)
        myreader.Fill(mydatatable)
        grd_orderslist.DataSource = mydatatable

    End Sub

    'to select a order
    Private Sub get_current_id()

        Dim current_row As Integer = grd_orderslist.CurrentRow.Index
        current_id = grd_orderslist(0, current_row).Value

    End Sub

    Private Sub grd_orderslist_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grd_orderslist.CellClick

        get_current_id()

    End Sub

    Private Sub btn_showinvoice_Click(sender As Object, e As EventArgs) Handles btn_showinvoice.Click

        'SQL for textbox
        Dim mysql As String = "SELECT TBL_PURCHASES_A181765.FLD_ORDER_ID, TBL_ORDERS_A181765.FLD_ORDER_DATE, TBL_PURCHASES_A181765.FLD_CUST_ID, TBL_CUSTOMERS_A181765.FLD_CUST_NAME," _
                            & " TBL_CUSTOMERS_A181765.FLD_CUST_ADDRESS, TBL_CUSTOMERS_A181765.FLD_CUST_PHONENO, TBL_STAFFS_A181765.FLD_STAFF_NAME, TBL_STAFFS_A181765.FLD_PHONE_NO" _
                            & " FROM TBL_STAFFS_A181765 INNER JOIN (TBL_ORDERS_A181765 INNER JOIN (TBL_PRODUCTS_A181765 INNER JOIN (TBL_CUSTOMERS_A181765" _
                            & " INNER JOIN TBL_PURCHASES_A181765 ON TBL_CUSTOMERS_A181765.FLD_CUST_ID = TBL_PURCHASES_A181765.FLD_CUST_ID) ON TBL_PRODUCTS_A181765.FLD_PRODUCT_ID = TBL_PURCHASES_A181765.FLD_PRODUCT_ID)" _
                            & " ON TBL_ORDERS_A181765.FLD_ORDER_ID = TBL_PURCHASES_A181765.FLD_ORDER_ID) ON TBL_STAFFS_A181765.FLD_STAFF_ID = TBL_ORDERS_A181765.FLD_STAFF_ID" _
                            & " WHERE (((TBL_PURCHASES_A181765.FLD_ORDER_ID)='" & current_id & "'))"

        Dim mydatatable As New DataTable
        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)
        myreader.Fill(mydatatable)
        txt_orderid.Text = mydatatable.Rows(0).Item("FLD_ORDER_ID")
        txt_orderdate.Text = mydatatable.Rows(0).Item("FLD_ORDER_DATE")
        txt_custname.Text = mydatatable.Rows(0).Item("FLD_CUST_NAME")
        txt_custaddress.Text = mydatatable.Rows(0).Item("FLD_CUST_ADDRESS")
        txt_custphone.Text = mydatatable.Rows(0).Item("FLD_CUST_PHONENO")
        txt_staffname.Text = mydatatable.Rows(0).Item("FLD_STAFF_NAME")
        txt_staffphone.Text = mydatatable.Rows(0).Item("FLD_PHONE_NO")


        'SQL for table
        Dim mysql2 As String = "SELECT TBL_PURCHASES_A181765.FLD_PRODUCT_ID, TBL_PRODUCTS_A181765.FLD_PRODUCT_NAME, TBL_PURCHASES_A181765.FLD_PRICE, TBL_PURCHASES_A181765.FLD_QUANTITY, [TBL_PURCHASES_A181765]![FLD_PRICE]*[TBL_PURCHASES_A181765]![FLD_QUANTITY] AS Subtotal" _
                            & " FROM TBL_CUSTOMERS_A181765 INNER JOIN (TBL_STAFFS_A181765 INNER JOIN (TBL_ORDERS_A181765 INNER JOIN (TBL_PRODUCTS_A181765 INNER JOIN TBL_PURCHASES_A181765 ON TBL_PRODUCTS_A181765.FLD_PRODUCT_ID = TBL_PURCHASES_A181765.FLD_PRODUCT_ID)" _
                            & " ON TBL_ORDERS_A181765.FLD_ORDER_ID = TBL_PURCHASES_A181765.FLD_ORDER_ID) ON TBL_STAFFS_A181765.FLD_STAFF_ID = TBL_ORDERS_A181765.FLD_STAFF_ID) ON TBL_CUSTOMERS_A181765.FLD_CUST_ID = TBL_PURCHASES_A181765.FLD_CUST_ID" _
                            & " WHERE (((TBL_PURCHASES_A181765.FLD_ORDER_ID)='" & current_id & "'))"

        Dim mydatatable2 As New DataTable
        Dim myreader2 As New OleDb.OleDbDataAdapter(mysql2, myconnection)
        myreader2.Fill(mydatatable2)
        grd_orderdetails.DataSource = mydatatable2

        grd_orderdetails.Columns(0).HeaderText = "Book ID"
        grd_orderdetails.Columns(1).HeaderText = "Book Title"
        grd_orderdetails.Columns(2).HeaderText = "Price"
        grd_orderdetails.Columns(3).HeaderText = "Quantity"


        'calculate total RM
        Dim sum_subtotal As Decimal
        For Each row As DataGridViewRow In grd_orderdetails.Rows
            sum_subtotal += row.Cells(4).Value
        Next
        txt_total.Text = "RM" & sum_subtotal

        refresh_grid()
        get_current_id()

    End Sub

    Private Sub btn_back_Click(sender As Object, e As EventArgs) Handles btn_back.Click

        frm_orderslist_a181765.Show()
        Me.Hide()

    End Sub
End Class