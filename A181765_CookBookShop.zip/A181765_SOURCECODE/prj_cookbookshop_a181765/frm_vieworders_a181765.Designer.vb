﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_vieworders_a181765
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_vieworders_a181765))
        Me.grd_orderslist = New System.Windows.Forms.DataGridView()
        Me.grd_orderdetails = New System.Windows.Forms.DataGridView()
        Me.txt_custphone = New System.Windows.Forms.TextBox()
        Me.txt_custaddress = New System.Windows.Forms.TextBox()
        Me.txt_custname = New System.Windows.Forms.TextBox()
        Me.txt_orderdate = New System.Windows.Forms.TextBox()
        Me.txt_orderid = New System.Windows.Forms.TextBox()
        Me.txt_total = New System.Windows.Forms.TextBox()
        Me.txt_staffname = New System.Windows.Forms.TextBox()
        Me.txt_staffphone = New System.Windows.Forms.TextBox()
        Me.btn_showinvoice = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lbl_invoicetitle = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.pnl_invoice = New System.Windows.Forms.Panel()
        Me.btn_back = New System.Windows.Forms.Button()
        CType(Me.grd_orderslist, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grd_orderdetails, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnl_invoice.SuspendLayout()
        Me.SuspendLayout()
        '
        'grd_orderslist
        '
        Me.grd_orderslist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.grd_orderslist.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.DarkSeaGreen
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd_orderslist.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grd_orderslist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grd_orderslist.DefaultCellStyle = DataGridViewCellStyle2
        Me.grd_orderslist.GridColor = System.Drawing.Color.Black
        Me.grd_orderslist.Location = New System.Drawing.Point(25, 109)
        Me.grd_orderslist.Name = "grd_orderslist"
        Me.grd_orderslist.ReadOnly = True
        Me.grd_orderslist.Size = New System.Drawing.Size(243, 303)
        Me.grd_orderslist.TabIndex = 0
        '
        'grd_orderdetails
        '
        Me.grd_orderdetails.AllowUserToAddRows = False
        Me.grd_orderdetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.grd_orderdetails.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.grd_orderdetails.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grd_orderdetails.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.SkyBlue
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd_orderdetails.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.grd_orderdetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.LightCyan
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd_orderdetails.DefaultCellStyle = DataGridViewCellStyle4
        Me.grd_orderdetails.EnableHeadersVisualStyles = False
        Me.grd_orderdetails.GridColor = System.Drawing.Color.Black
        Me.grd_orderdetails.Location = New System.Drawing.Point(15, 188)
        Me.grd_orderdetails.Name = "grd_orderdetails"
        Me.grd_orderdetails.ReadOnly = True
        Me.grd_orderdetails.Size = New System.Drawing.Size(452, 173)
        Me.grd_orderdetails.TabIndex = 1
        '
        'txt_custphone
        '
        Me.txt_custphone.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txt_custphone.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_custphone.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_custphone.Location = New System.Drawing.Point(15, 168)
        Me.txt_custphone.Name = "txt_custphone"
        Me.txt_custphone.ReadOnly = True
        Me.txt_custphone.Size = New System.Drawing.Size(132, 14)
        Me.txt_custphone.TabIndex = 2
        '
        'txt_custaddress
        '
        Me.txt_custaddress.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txt_custaddress.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_custaddress.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_custaddress.Location = New System.Drawing.Point(15, 148)
        Me.txt_custaddress.Name = "txt_custaddress"
        Me.txt_custaddress.ReadOnly = True
        Me.txt_custaddress.Size = New System.Drawing.Size(132, 14)
        Me.txt_custaddress.TabIndex = 3
        '
        'txt_custname
        '
        Me.txt_custname.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txt_custname.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_custname.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_custname.Location = New System.Drawing.Point(15, 125)
        Me.txt_custname.Name = "txt_custname"
        Me.txt_custname.ReadOnly = True
        Me.txt_custname.Size = New System.Drawing.Size(132, 17)
        Me.txt_custname.TabIndex = 4
        '
        'txt_orderdate
        '
        Me.txt_orderdate.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txt_orderdate.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_orderdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_orderdate.Location = New System.Drawing.Point(385, 170)
        Me.txt_orderdate.Name = "txt_orderdate"
        Me.txt_orderdate.ReadOnly = True
        Me.txt_orderdate.Size = New System.Drawing.Size(82, 14)
        Me.txt_orderdate.TabIndex = 5
        '
        'txt_orderid
        '
        Me.txt_orderid.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txt_orderid.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_orderid.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_orderid.Location = New System.Drawing.Point(385, 150)
        Me.txt_orderid.Name = "txt_orderid"
        Me.txt_orderid.ReadOnly = True
        Me.txt_orderid.Size = New System.Drawing.Size(82, 14)
        Me.txt_orderid.TabIndex = 6
        '
        'txt_total
        '
        Me.txt_total.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txt_total.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_total.Location = New System.Drawing.Point(335, 367)
        Me.txt_total.Name = "txt_total"
        Me.txt_total.ReadOnly = True
        Me.txt_total.Size = New System.Drawing.Size(132, 20)
        Me.txt_total.TabIndex = 7
        '
        'txt_staffname
        '
        Me.txt_staffname.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txt_staffname.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_staffname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_staffname.Location = New System.Drawing.Point(15, 403)
        Me.txt_staffname.Name = "txt_staffname"
        Me.txt_staffname.ReadOnly = True
        Me.txt_staffname.Size = New System.Drawing.Size(132, 14)
        Me.txt_staffname.TabIndex = 8
        '
        'txt_staffphone
        '
        Me.txt_staffphone.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txt_staffphone.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_staffphone.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_staffphone.Location = New System.Drawing.Point(15, 423)
        Me.txt_staffphone.Name = "txt_staffphone"
        Me.txt_staffphone.ReadOnly = True
        Me.txt_staffphone.Size = New System.Drawing.Size(132, 14)
        Me.txt_staffphone.TabIndex = 9
        '
        'btn_showinvoice
        '
        Me.btn_showinvoice.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btn_showinvoice.Location = New System.Drawing.Point(161, 418)
        Me.btn_showinvoice.Name = "btn_showinvoice"
        Me.btn_showinvoice.Size = New System.Drawing.Size(107, 34)
        Me.btn_showinvoice.TabIndex = 10
        Me.btn_showinvoice.Text = "View Invoice"
        Me.btn_showinvoice.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(326, 152)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 13)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Order ID :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(314, 170)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 13)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "Order Date :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(292, 370)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(37, 13)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Total :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 387)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(73, 13)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "Managed By :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 109)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(92, 13)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "Customer Details :"
        '
        'lbl_invoicetitle
        '
        Me.lbl_invoicetitle.AutoSize = True
        Me.lbl_invoicetitle.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_invoicetitle.Location = New System.Drawing.Point(176, 10)
        Me.lbl_invoicetitle.Name = "lbl_invoicetitle"
        Me.lbl_invoicetitle.Size = New System.Drawing.Size(141, 23)
        Me.lbl_invoicetitle.TabIndex = 16
        Me.lbl_invoicetitle.Text = "Payment Invoice"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(166, 33)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(163, 48)
        Me.Label6.TabIndex = 17
        Me.Label6.Text = "Cookbook Shop" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "21, Jalan Kledang Raya 7," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Taman Kledang Jaya"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnl_invoice
        '
        Me.pnl_invoice.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.pnl_invoice.Controls.Add(Me.Label5)
        Me.pnl_invoice.Controls.Add(Me.Label3)
        Me.pnl_invoice.Controls.Add(Me.Label4)
        Me.pnl_invoice.Controls.Add(Me.Label6)
        Me.pnl_invoice.Controls.Add(Me.txt_total)
        Me.pnl_invoice.Controls.Add(Me.lbl_invoicetitle)
        Me.pnl_invoice.Controls.Add(Me.Label2)
        Me.pnl_invoice.Controls.Add(Me.txt_staffphone)
        Me.pnl_invoice.Controls.Add(Me.txt_custname)
        Me.pnl_invoice.Controls.Add(Me.txt_staffname)
        Me.pnl_invoice.Controls.Add(Me.Label1)
        Me.pnl_invoice.Controls.Add(Me.txt_custphone)
        Me.pnl_invoice.Controls.Add(Me.grd_orderdetails)
        Me.pnl_invoice.Controls.Add(Me.txt_custaddress)
        Me.pnl_invoice.Controls.Add(Me.txt_orderdate)
        Me.pnl_invoice.Controls.Add(Me.txt_orderid)
        Me.pnl_invoice.Location = New System.Drawing.Point(359, 29)
        Me.pnl_invoice.Name = "pnl_invoice"
        Me.pnl_invoice.Size = New System.Drawing.Size(481, 468)
        Me.pnl_invoice.TabIndex = 18
        '
        'btn_back
        '
        Me.btn_back.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btn_back.Location = New System.Drawing.Point(25, 12)
        Me.btn_back.Name = "btn_back"
        Me.btn_back.Size = New System.Drawing.Size(91, 34)
        Me.btn_back.TabIndex = 19
        Me.btn_back.Text = "BACK"
        Me.btn_back.UseVisualStyleBackColor = False
        '
        'frm_vieworders_a181765
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(863, 509)
        Me.Controls.Add(Me.btn_back)
        Me.Controls.Add(Me.pnl_invoice)
        Me.Controls.Add(Me.btn_showinvoice)
        Me.Controls.Add(Me.grd_orderslist)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frm_vieworders_a181765"
        Me.Text = "Order History"
        CType(Me.grd_orderslist, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grd_orderdetails, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnl_invoice.ResumeLayout(False)
        Me.pnl_invoice.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grd_orderslist As DataGridView
    Friend WithEvents grd_orderdetails As DataGridView
    Friend WithEvents txt_custphone As TextBox
    Friend WithEvents txt_custaddress As TextBox
    Friend WithEvents txt_custname As TextBox
    Friend WithEvents txt_orderdate As TextBox
    Friend WithEvents txt_orderid As TextBox
    Friend WithEvents txt_total As TextBox
    Friend WithEvents txt_staffname As TextBox
    Friend WithEvents txt_staffphone As TextBox
    Friend WithEvents btn_showinvoice As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lbl_invoicetitle As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents pnl_invoice As Panel
    Friend WithEvents btn_back As Button
End Class
