﻿Public Class frm_updateproducts_a181765

    Dim current_id As String

    Private Sub frm_updateproducts_a181765_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        refresh_grid()

        get_current_id()

        grd_products.Columns(0).HeaderText = "Book ID"
        grd_products.Columns(1).HeaderText = "Book Name"
        grd_products.Columns(2).HeaderText = "Price (RM)"
        grd_products.Columns(3).HeaderText = "Author"
        grd_products.Columns(4).HeaderText = "Publisher"
        grd_products.Columns(5).HeaderText = "Number of Pages"
        grd_products.Columns(6).HeaderText = "ISBN"

    End Sub

    Private Sub refresh_grid()

        Dim mysql As String = "SELECT * FROM TBL_PRODUCTS_A181765"

        Dim mydatatable As New DataTable

        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)

        myreader.Fill(mydatatable)

        grd_products.DataSource = mydatatable

    End Sub

    Private Sub clear_fields()

        txt_id.Text = ""
        txt_name.Text = ""
        txt_price.Text = ""
        txt_author.Text = ""
        txt_publisher.Text = ""
        txt_pagenum.Text = ""
        txt_isbn.Text = ""

    End Sub

    Private Sub get_current_id()

        Dim current_row As Integer = grd_products.CurrentRow.Index

        current_id = grd_products(0, current_row).Value

        txt_id.Text = current_id
        txt_name.Text = grd_products(1, current_row).Value
        txt_price.Text = grd_products(2, current_row).Value
        txt_author.Text = grd_products(3, current_row).Value
        txt_publisher.Text = grd_products(4, current_row).Value
        txt_pagenum.Text = grd_products(5, current_row).Value
        txt_isbn.Text = grd_products(6, current_row).Value

    End Sub

    Private Sub grd_products_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grd_products.CellClick

        get_current_id()

    End Sub

    Private Sub btn_update_Click(sender As Object, e As EventArgs) Handles btn_update.Click

        run_sql_command("UPDATE TBL_PRODUCTS_A181765 SET FLD_PRODUCT_NAME='" & txt_name.Text & "', FLD_PRICE='" & txt_price.Text & "', FLD_AUTHOR='" & txt_author.Text _
                        & "', FLD_PUBLISHER='" & txt_publisher.Text & "', FLD_NUM_PAGES=" & txt_pagenum.Text & ", FLD_ISBN='" & txt_isbn.Text & "' WHERE FLD_PRODUCT_ID='" & current_id & "'")

        Beep()
        MsgBox("You have successfully updated the products """ & current_id & """.", MsgBoxStyle.Information, "Update Successful")

        refresh_grid()
        clear_fields()
        get_current_id()

    End Sub

    Private Sub btn_delete_Click(sender As Object, e As EventArgs) Handles btn_delete.Click

        Dim delete_confirmation = MsgBox("Are you sure you would like to delete the product """ & current_id & """?", MsgBoxStyle.YesNo)

        If delete_confirmation = MsgBoxResult.Yes Then

            run_sql_command("DELETE FROM TBL_PRODUCTS_A181765 WHERE FLD_PRODUCT_ID='" & current_id & "'")

            Kill("pictures\" & txt_id.Text & ".jpg")

            Beep()
            MsgBox("The customer """ & current_id & """ has been successfully deleted.", MsgBoxStyle.Information, "Delete Successful")

            refresh_grid()
            clear_fields()
            get_current_id()

        End If

    End Sub

    Private Sub btn_mainmenu_Click(sender As Object, e As EventArgs) Handles btn_mainmenu.Click

        frm_productslist_a181765.Show()
        Me.Hide()

    End Sub
End Class