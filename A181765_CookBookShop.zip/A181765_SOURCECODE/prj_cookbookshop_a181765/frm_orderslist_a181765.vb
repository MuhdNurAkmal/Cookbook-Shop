﻿Public Class frm_orderslist_a181765
    Private Sub frm_orderslist_a181765_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim mysql As String = "SELECT TBL_ORDERS_A181765.FLD_ORDER_ID, TBL_ORDERS_A181765.FLD_ORDER_DATE, TBL_ORDERS_A181765.FLD_STAFF_ID, TBL_STAFFS_A181765.FLD_STAFF_NAME" _
                              & " FROM TBL_STAFFS_A181765 INNER JOIN TBL_ORDERS_A181765 ON TBL_STAFFS_A181765.FLD_STAFF_ID = TBL_ORDERS_A181765.FLD_STAFF_ID"

        Dim mydatatable As New DataTable

        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)

        myreader.Fill(mydatatable)

        grd_orders.DataSource = mydatatable

        grd_orders.Columns(0).HeaderText = "Order ID"
        grd_orders.Columns(1).HeaderText = "Order Date"
        grd_orders.Columns(2).HeaderText = "Staff ID"
        grd_orders.Columns(3).HeaderText = "Staff Name"

        refresh_grid()

    End Sub

    Private Sub refresh_grid()

        Dim mysql As String = "SELECT TBL_ORDERS_A181765.FLD_ORDER_ID, TBL_ORDERS_A181765.FLD_ORDER_DATE, TBL_ORDERS_A181765.FLD_STAFF_ID, TBL_STAFFS_A181765.FLD_STAFF_NAME" _
                              & " FROM TBL_STAFFS_A181765 INNER JOIN TBL_ORDERS_A181765 ON TBL_STAFFS_A181765.FLD_STAFF_ID = TBL_ORDERS_A181765.FLD_STAFF_ID"

        Dim mydatatable As New DataTable

        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)

        myreader.Fill(mydatatable)

        grd_orders.DataSource = mydatatable

    End Sub

    Private Sub btn_back_Click(sender As Object, e As EventArgs) Handles btn_back.Click

        frm_menu_a181765.Show()
        Me.Hide()

    End Sub

    Private Sub btn_orderhistory_Click(sender As Object, e As EventArgs) Handles btn_orderhistory.Click

        frm_vieworders_a181765.Show()
        Me.Hide()

    End Sub

    Private Sub btn_neworder_Click(sender As Object, e As EventArgs) Handles btn_neworder.Click

        frm_makeorders_a181765.Show()
        Me.Hide()

    End Sub
End Class