﻿Public Class frm_updatecustomer_a181765

    Dim current_id As String

    Private Sub frm_updatecustomer_a181765_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        refresh_grid()

        get_current_id()

        grd_customer.Columns(0).HeaderText = "Customer ID"
        grd_customer.Columns(1).HeaderText = "Customer Name"
        grd_customer.Columns(2).HeaderText = "Home Address"
        grd_customer.Columns(3).HeaderText = "Phone Number"

    End Sub

    Private Sub refresh_grid()

        Dim mysql As String = "SELECT * FROM TBL_CUSTOMERS_A181765"

        Dim mydatatable As New DataTable

        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)

        myreader.Fill(mydatatable)

        grd_customer.DataSource = mydatatable

    End Sub

    Private Sub clear_fields()

        txt_custid.Text = ""
        txt_name.Text = ""
        txt_address.Text = ""
        txt_phone.Text = ""

    End Sub

    Private Sub get_current_id()

        Dim current_row As Integer = grd_customer.CurrentRow.Index

        current_id = grd_customer(0, current_row).Value

        txt_custid.Text = current_id
        txt_name.Text = grd_customer(1, current_row).Value
        txt_address.Text = grd_customer(2, current_row).Value
        txt_phone.Text = grd_customer(3, current_row).Value

    End Sub

    Private Sub grd_customer_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grd_customer.CellClick

        get_current_id()

    End Sub

    Private Sub btn_update_Click(sender As Object, e As EventArgs) Handles btn_update.Click

        run_sql_command("UPDATE TBL_CUSTOMERS_A181765 SET FLD_CUST_NAME='" & txt_name.Text & "', FLD_CUST_ADDRESS='" & txt_address.Text & "', FLD_CUST_PHONENO='" & txt_phone.Text & "' WHERE FLD_CUST_ID='" & current_id & "'")

        Beep()
        MsgBox("You have successfully updated the details for customer """ & current_id & """.", MsgBoxStyle.Information, "Update Successful")

        refresh_grid()
        clear_fields()
        get_current_id()

    End Sub

    Private Sub btn_delete_Click(sender As Object, e As EventArgs) Handles btn_delete.Click

        Dim delete_confirmation = MsgBox("Are you sure you would like to delete the customer """ & current_id & """?", MsgBoxStyle.YesNo)

        If delete_confirmation = MsgBoxResult.Yes Then

            run_sql_command("DELETE FROM TBL_CUSTOMERS_A181765 WHERE FLD_CUST_ID='" & current_id & "'")

            Beep()
            MsgBox("The customer """ & current_id & """ has been successfully deleted.", MsgBoxStyle.Information, "Delete Successful")

            refresh_grid()
            clear_fields()
            get_current_id()

        End If

    End Sub

    Private Sub btn_mainmenu_Click(sender As Object, e As EventArgs) Handles btn_mainmenu.Click

        frm_customerslist_a181765.Show()
        Me.Hide()

    End Sub
End Class