﻿Public Class frm_staffslist_a181765
    Private Sub frm_staffslist_a181765_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim mysql As String = "SELECT * FROM TBL_STAFFS_A181765"

        Dim mydatatable As New DataTable

        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)

        myreader.Fill(mydatatable)

        grd_staffs.DataSource = mydatatable

        grd_staffs.Columns(0).HeaderText = "Staff ID"
        grd_staffs.Columns(1).HeaderText = "Staff Name"
        grd_staffs.Columns(2).HeaderText = "Phone Number"

        refresh_grid()

    End Sub

    Private Sub refresh_grid()

        Dim mysql As String = "SELECT * FROM TBL_STAFFS_A181765"

        Dim mydatatable As New DataTable

        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)

        myreader.Fill(mydatatable)

        grd_staffs.DataSource = mydatatable

    End Sub

    Private Sub btn_back_Click(sender As Object, e As EventArgs) Handles btn_back.Click

        frm_menu_a181765.Show()
        Me.Hide()

    End Sub

    Private Sub btn_addstaff_Click(sender As Object, e As EventArgs) Handles btn_addstaff.Click

        frm_insertstaff_a181765.Show()
        Me.Hide()

    End Sub

    Private Sub btn_editstaff_Click(sender As Object, e As EventArgs) Handles btn_editstaff.Click

        frm_updatestaff_a181765.Show()
        Me.Hide()

    End Sub
End Class