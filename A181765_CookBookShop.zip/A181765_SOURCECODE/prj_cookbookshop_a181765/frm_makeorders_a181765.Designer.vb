﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_makeorders_a181765
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_makeorders_a181765))
        Me.grd_purchases = New System.Windows.Forms.DataGridView()
        Me.lst_productid = New System.Windows.Forms.ListBox()
        Me.pic_bookpics = New System.Windows.Forms.PictureBox()
        Me.txt_bookprice = New System.Windows.Forms.TextBox()
        Me.txt_booktitle = New System.Windows.Forms.TextBox()
        Me.txt_bookid = New System.Windows.Forms.TextBox()
        Me.txt_numpage = New System.Windows.Forms.TextBox()
        Me.txt_publisher = New System.Windows.Forms.TextBox()
        Me.txt_bookauthor = New System.Windows.Forms.TextBox()
        Me.txt_isbn = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.btn_addtocart = New System.Windows.Forms.Button()
        Me.btn_purchases = New System.Windows.Forms.Button()
        Me.txt_phoneno = New System.Windows.Forms.TextBox()
        Me.txt_address = New System.Windows.Forms.TextBox()
        Me.txt_custname = New System.Windows.Forms.TextBox()
        Me.cmb_custid = New System.Windows.Forms.ComboBox()
        Me.cmb_staffid = New System.Windows.Forms.ComboBox()
        Me.txt_staffphoneno = New System.Windows.Forms.TextBox()
        Me.txt_staffname = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txt_total = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txt_orderid = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txt_quantity = New System.Windows.Forms.TextBox()
        Me.btn_minusqtty = New System.Windows.Forms.Button()
        Me.btn_addqtty = New System.Windows.Forms.Button()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txt_orderdate = New System.Windows.Forms.TextBox()
        Me.btn_remove = New System.Windows.Forms.Button()
        Me.lbl_insert = New System.Windows.Forms.Label()
        Me.btn_back = New System.Windows.Forms.Button()
        CType(Me.grd_purchases, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_bookpics, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grd_purchases
        '
        Me.grd_purchases.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.grd_purchases.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.grd_purchases.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.SkyBlue
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd_purchases.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grd_purchases.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.LightCyan
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grd_purchases.DefaultCellStyle = DataGridViewCellStyle2
        Me.grd_purchases.GridColor = System.Drawing.Color.Black
        Me.grd_purchases.Location = New System.Drawing.Point(451, 269)
        Me.grd_purchases.Name = "grd_purchases"
        Me.grd_purchases.Size = New System.Drawing.Size(511, 215)
        Me.grd_purchases.TabIndex = 5
        '
        'lst_productid
        '
        Me.lst_productid.FormattingEnabled = True
        Me.lst_productid.Location = New System.Drawing.Point(12, 111)
        Me.lst_productid.Name = "lst_productid"
        Me.lst_productid.Size = New System.Drawing.Size(88, 407)
        Me.lst_productid.TabIndex = 10
        '
        'pic_bookpics
        '
        Me.pic_bookpics.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pic_bookpics.Location = New System.Drawing.Point(206, 111)
        Me.pic_bookpics.Name = "pic_bookpics"
        Me.pic_bookpics.Size = New System.Drawing.Size(114, 147)
        Me.pic_bookpics.TabIndex = 11
        Me.pic_bookpics.TabStop = False
        '
        'txt_bookprice
        '
        Me.txt_bookprice.Location = New System.Drawing.Point(206, 375)
        Me.txt_bookprice.Name = "txt_bookprice"
        Me.txt_bookprice.Size = New System.Drawing.Size(207, 20)
        Me.txt_bookprice.TabIndex = 14
        '
        'txt_booktitle
        '
        Me.txt_booktitle.Location = New System.Drawing.Point(206, 313)
        Me.txt_booktitle.Multiline = True
        Me.txt_booktitle.Name = "txt_booktitle"
        Me.txt_booktitle.Size = New System.Drawing.Size(207, 56)
        Me.txt_booktitle.TabIndex = 13
        '
        'txt_bookid
        '
        Me.txt_bookid.Location = New System.Drawing.Point(206, 287)
        Me.txt_bookid.Name = "txt_bookid"
        Me.txt_bookid.Size = New System.Drawing.Size(207, 20)
        Me.txt_bookid.TabIndex = 12
        '
        'txt_numpage
        '
        Me.txt_numpage.Location = New System.Drawing.Point(206, 459)
        Me.txt_numpage.Name = "txt_numpage"
        Me.txt_numpage.Size = New System.Drawing.Size(207, 20)
        Me.txt_numpage.TabIndex = 17
        '
        'txt_publisher
        '
        Me.txt_publisher.Location = New System.Drawing.Point(206, 427)
        Me.txt_publisher.Name = "txt_publisher"
        Me.txt_publisher.Size = New System.Drawing.Size(207, 20)
        Me.txt_publisher.TabIndex = 16
        '
        'txt_bookauthor
        '
        Me.txt_bookauthor.Location = New System.Drawing.Point(206, 401)
        Me.txt_bookauthor.Name = "txt_bookauthor"
        Me.txt_bookauthor.Size = New System.Drawing.Size(207, 20)
        Me.txt_bookauthor.TabIndex = 15
        '
        'txt_isbn
        '
        Me.txt_isbn.Location = New System.Drawing.Point(206, 490)
        Me.txt_isbn.Name = "txt_isbn"
        Me.txt_isbn.Size = New System.Drawing.Size(207, 20)
        Me.txt_isbn.TabIndex = 18
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(129, 378)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(37, 13)
        Me.Label5.TabIndex = 22
        Me.Label5.Text = "Price :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(129, 404)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 13)
        Me.Label6.TabIndex = 21
        Me.Label6.Text = "Author :"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(129, 336)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(62, 13)
        Me.Label7.TabIndex = 20
        Me.Label7.Text = "Book TItle :"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(129, 290)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(52, 13)
        Me.Label8.TabIndex = 19
        Me.Label8.Text = "Book ID :"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(129, 493)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(38, 13)
        Me.Label9.TabIndex = 26
        Me.Label9.Text = "ISBN :"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(129, 456)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(55, 26)
        Me.Label11.TabIndex = 24
        Me.Label11.Text = "Number" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "of Pages :"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(129, 430)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(56, 13)
        Me.Label12.TabIndex = 23
        Me.Label12.Text = "Publisher :"
        '
        'btn_addtocart
        '
        Me.btn_addtocart.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btn_addtocart.Location = New System.Drawing.Point(322, 516)
        Me.btn_addtocart.Name = "btn_addtocart"
        Me.btn_addtocart.Size = New System.Drawing.Size(91, 38)
        Me.btn_addtocart.TabIndex = 27
        Me.btn_addtocart.Text = "Add To Cart"
        Me.btn_addtocart.UseVisualStyleBackColor = False
        '
        'btn_purchases
        '
        Me.btn_purchases.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btn_purchases.Location = New System.Drawing.Point(868, 516)
        Me.btn_purchases.Name = "btn_purchases"
        Me.btn_purchases.Size = New System.Drawing.Size(94, 38)
        Me.btn_purchases.TabIndex = 28
        Me.btn_purchases.Text = "Purchase"
        Me.btn_purchases.UseVisualStyleBackColor = False
        '
        'txt_phoneno
        '
        Me.txt_phoneno.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txt_phoneno.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_phoneno.Location = New System.Drawing.Point(542, 202)
        Me.txt_phoneno.Name = "txt_phoneno"
        Me.txt_phoneno.ReadOnly = True
        Me.txt_phoneno.Size = New System.Drawing.Size(148, 13)
        Me.txt_phoneno.TabIndex = 32
        '
        'txt_address
        '
        Me.txt_address.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txt_address.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_address.Location = New System.Drawing.Point(542, 176)
        Me.txt_address.Name = "txt_address"
        Me.txt_address.ReadOnly = True
        Me.txt_address.Size = New System.Drawing.Size(148, 13)
        Me.txt_address.TabIndex = 31
        '
        'txt_custname
        '
        Me.txt_custname.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txt_custname.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_custname.Location = New System.Drawing.Point(542, 150)
        Me.txt_custname.Name = "txt_custname"
        Me.txt_custname.ReadOnly = True
        Me.txt_custname.Size = New System.Drawing.Size(148, 13)
        Me.txt_custname.TabIndex = 30
        '
        'cmb_custid
        '
        Me.cmb_custid.FormattingEnabled = True
        Me.cmb_custid.Location = New System.Drawing.Point(542, 123)
        Me.cmb_custid.Name = "cmb_custid"
        Me.cmb_custid.Size = New System.Drawing.Size(101, 21)
        Me.cmb_custid.TabIndex = 33
        '
        'cmb_staffid
        '
        Me.cmb_staffid.FormattingEnabled = True
        Me.cmb_staffid.Location = New System.Drawing.Point(814, 123)
        Me.cmb_staffid.Name = "cmb_staffid"
        Me.cmb_staffid.Size = New System.Drawing.Size(101, 21)
        Me.cmb_staffid.TabIndex = 38
        '
        'txt_staffphoneno
        '
        Me.txt_staffphoneno.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txt_staffphoneno.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_staffphoneno.Location = New System.Drawing.Point(814, 176)
        Me.txt_staffphoneno.Name = "txt_staffphoneno"
        Me.txt_staffphoneno.ReadOnly = True
        Me.txt_staffphoneno.Size = New System.Drawing.Size(148, 13)
        Me.txt_staffphoneno.TabIndex = 36
        '
        'txt_staffname
        '
        Me.txt_staffname.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txt_staffname.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_staffname.Location = New System.Drawing.Point(814, 150)
        Me.txt_staffname.Name = "txt_staffname"
        Me.txt_staffname.ReadOnly = True
        Me.txt_staffname.Size = New System.Drawing.Size(148, 13)
        Me.txt_staffname.TabIndex = 35
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(448, 126)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(71, 13)
        Me.Label1.TabIndex = 39
        Me.Label1.Text = "Customer ID :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(448, 153)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(88, 13)
        Me.Label2.TabIndex = 40
        Me.Label2.Text = "Customer Name :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(448, 179)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(82, 13)
        Me.Label3.TabIndex = 41
        Me.Label3.Text = "Home Address :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(448, 205)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 13)
        Me.Label4.TabIndex = 42
        Me.Label4.Text = "Phone No. :"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(742, 179)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(64, 13)
        Me.Label13.TabIndex = 45
        Me.Label13.Text = "Phone No. :"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(742, 153)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(66, 13)
        Me.Label14.TabIndex = 44
        Me.Label14.Text = "Staff Name :"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(742, 126)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(49, 13)
        Me.Label15.TabIndex = 43
        Me.Label15.Text = "Staff ID :"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(771, 493)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(37, 13)
        Me.Label10.TabIndex = 47
        Me.Label10.Text = "Total :"
        '
        'txt_total
        '
        Me.txt_total.Location = New System.Drawing.Point(814, 490)
        Me.txt_total.Name = "txt_total"
        Me.txt_total.Size = New System.Drawing.Size(148, 20)
        Me.txt_total.TabIndex = 46
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(449, 246)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(53, 13)
        Me.Label16.TabIndex = 49
        Me.Label16.Text = "Order ID :"
        '
        'txt_orderid
        '
        Me.txt_orderid.Location = New System.Drawing.Point(508, 243)
        Me.txt_orderid.Name = "txt_orderid"
        Me.txt_orderid.Size = New System.Drawing.Size(148, 20)
        Me.txt_orderid.TabIndex = 48
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(129, 525)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(52, 13)
        Me.Label17.TabIndex = 51
        Me.Label17.Text = "Quantity :"
        '
        'txt_quantity
        '
        Me.txt_quantity.Location = New System.Drawing.Point(235, 516)
        Me.txt_quantity.Multiline = True
        Me.txt_quantity.Name = "txt_quantity"
        Me.txt_quantity.Size = New System.Drawing.Size(55, 30)
        Me.txt_quantity.TabIndex = 50
        Me.txt_quantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_minusqtty
        '
        Me.btn_minusqtty.Location = New System.Drawing.Point(206, 516)
        Me.btn_minusqtty.Name = "btn_minusqtty"
        Me.btn_minusqtty.Size = New System.Drawing.Size(30, 30)
        Me.btn_minusqtty.TabIndex = 52
        Me.btn_minusqtty.Text = "-"
        Me.btn_minusqtty.UseVisualStyleBackColor = True
        '
        'btn_addqtty
        '
        Me.btn_addqtty.Location = New System.Drawing.Point(289, 516)
        Me.btn_addqtty.Name = "btn_addqtty"
        Me.btn_addqtty.Size = New System.Drawing.Size(30, 30)
        Me.btn_addqtty.TabIndex = 53
        Me.btn_addqtty.Text = "+"
        Me.btn_addqtty.UseVisualStyleBackColor = True
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(772, 246)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(36, 13)
        Me.Label18.TabIndex = 55
        Me.Label18.Text = "Date :"
        '
        'txt_orderdate
        '
        Me.txt_orderdate.Location = New System.Drawing.Point(814, 243)
        Me.txt_orderdate.Name = "txt_orderdate"
        Me.txt_orderdate.Size = New System.Drawing.Size(148, 20)
        Me.txt_orderdate.TabIndex = 54
        '
        'btn_remove
        '
        Me.btn_remove.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btn_remove.Location = New System.Drawing.Point(451, 490)
        Me.btn_remove.Name = "btn_remove"
        Me.btn_remove.Size = New System.Drawing.Size(85, 33)
        Me.btn_remove.TabIndex = 57
        Me.btn_remove.Text = "Remove"
        Me.btn_remove.UseVisualStyleBackColor = False
        '
        'lbl_insert
        '
        Me.lbl_insert.AutoSize = True
        Me.lbl_insert.Font = New System.Drawing.Font("Motion Picture Personal Use ", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_insert.Location = New System.Drawing.Point(410, 23)
        Me.lbl_insert.Name = "lbl_insert"
        Me.lbl_insert.Size = New System.Drawing.Size(177, 55)
        Me.lbl_insert.TabIndex = 58
        Me.lbl_insert.Text = "Order Form"
        '
        'btn_back
        '
        Me.btn_back.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btn_back.Location = New System.Drawing.Point(12, 12)
        Me.btn_back.Name = "btn_back"
        Me.btn_back.Size = New System.Drawing.Size(88, 42)
        Me.btn_back.TabIndex = 59
        Me.btn_back.Text = "BACK"
        Me.btn_back.UseVisualStyleBackColor = False
        '
        'frm_makeorders_a181765
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(986, 588)
        Me.Controls.Add(Me.btn_back)
        Me.Controls.Add(Me.lbl_insert)
        Me.Controls.Add(Me.btn_remove)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.txt_orderdate)
        Me.Controls.Add(Me.btn_addqtty)
        Me.Controls.Add(Me.btn_minusqtty)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.txt_quantity)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.txt_orderid)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.txt_total)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cmb_staffid)
        Me.Controls.Add(Me.txt_staffphoneno)
        Me.Controls.Add(Me.txt_staffname)
        Me.Controls.Add(Me.cmb_custid)
        Me.Controls.Add(Me.txt_phoneno)
        Me.Controls.Add(Me.txt_address)
        Me.Controls.Add(Me.txt_custname)
        Me.Controls.Add(Me.btn_purchases)
        Me.Controls.Add(Me.btn_addtocart)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txt_isbn)
        Me.Controls.Add(Me.txt_numpage)
        Me.Controls.Add(Me.txt_publisher)
        Me.Controls.Add(Me.txt_bookauthor)
        Me.Controls.Add(Me.txt_bookprice)
        Me.Controls.Add(Me.txt_booktitle)
        Me.Controls.Add(Me.txt_bookid)
        Me.Controls.Add(Me.pic_bookpics)
        Me.Controls.Add(Me.lst_productid)
        Me.Controls.Add(Me.grd_purchases)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frm_makeorders_a181765"
        Me.Text = "Order Form"
        CType(Me.grd_purchases, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_bookpics, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents grd_purchases As DataGridView
    Friend WithEvents lst_productid As ListBox
    Friend WithEvents pic_bookpics As PictureBox
    Friend WithEvents txt_bookprice As TextBox
    Friend WithEvents txt_booktitle As TextBox
    Friend WithEvents txt_bookid As TextBox
    Friend WithEvents txt_numpage As TextBox
    Friend WithEvents txt_publisher As TextBox
    Friend WithEvents txt_bookauthor As TextBox
    Friend WithEvents txt_isbn As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents btn_addtocart As Button
    Friend WithEvents btn_purchases As Button
    Friend WithEvents txt_phoneno As TextBox
    Friend WithEvents txt_address As TextBox
    Friend WithEvents txt_custname As TextBox
    Friend WithEvents cmb_custid As ComboBox
    Friend WithEvents cmb_staffid As ComboBox
    Friend WithEvents txt_staffphoneno As TextBox
    Friend WithEvents txt_staffname As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents txt_total As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents txt_orderid As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents txt_quantity As TextBox
    Friend WithEvents btn_minusqtty As Button
    Friend WithEvents btn_addqtty As Button
    Friend WithEvents Label18 As Label
    Friend WithEvents txt_orderdate As TextBox
    Friend WithEvents btn_remove As Button
    Friend WithEvents lbl_insert As Label
    Friend WithEvents btn_back As Button
End Class
