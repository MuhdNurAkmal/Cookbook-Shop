﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_splashscreen_a181765
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_splashscreen_a181765))
        Me.btn_start = New System.Windows.Forms.Button()
        Me.lbl_myname = New System.Windows.Forms.Label()
        Me.lbl_ownership = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btn_start
        '
        Me.btn_start.BackColor = System.Drawing.Color.MediumSeaGreen
        Me.btn_start.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_start.ForeColor = System.Drawing.Color.Black
        Me.btn_start.Location = New System.Drawing.Point(329, 323)
        Me.btn_start.Name = "btn_start"
        Me.btn_start.Size = New System.Drawing.Size(152, 54)
        Me.btn_start.TabIndex = 0
        Me.btn_start.Text = "Discover Now"
        Me.btn_start.UseVisualStyleBackColor = False
        '
        'lbl_myname
        '
        Me.lbl_myname.AutoSize = True
        Me.lbl_myname.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_myname.Location = New System.Drawing.Point(249, 264)
        Me.lbl_myname.Name = "lbl_myname"
        Me.lbl_myname.Size = New System.Drawing.Size(318, 38)
        Me.lbl_myname.TabIndex = 1
        Me.lbl_myname.Text = "Muhammad Nur Akmal bin Mohamad Razif" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "A181765"
        Me.lbl_myname.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbl_ownership
        '
        Me.lbl_ownership.AutoSize = True
        Me.lbl_ownership.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ownership.Location = New System.Drawing.Point(367, 236)
        Me.lbl_ownership.Name = "lbl_ownership"
        Me.lbl_ownership.Size = New System.Drawing.Size(88, 17)
        Me.lbl_ownership.TabIndex = 2
        Me.lbl_ownership.Text = "Created by :"
        Me.lbl_ownership.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frm_splashscreen_a181765
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lbl_ownership)
        Me.Controls.Add(Me.lbl_myname)
        Me.Controls.Add(Me.btn_start)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frm_splashscreen_a181765"
        Me.Text = "Welcome Page"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_start As Button
    Friend WithEvents lbl_myname As Label
    Friend WithEvents lbl_ownership As Label
End Class
