﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_menu_a181765
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_menu_a181765))
        Me.btn_exit = New System.Windows.Forms.Button()
        Me.btn_orderslist = New System.Windows.Forms.Button()
        Me.btn_purchaseslist = New System.Windows.Forms.Button()
        Me.btn_staffslist = New System.Windows.Forms.Button()
        Me.btn_customerslist = New System.Windows.Forms.Button()
        Me.btn_productlist = New System.Windows.Forms.Button()
        Me.btn_catalog = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btn_exit
        '
        Me.btn_exit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_exit.Font = New System.Drawing.Font("Nirmala UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_exit.Location = New System.Drawing.Point(344, 390)
        Me.btn_exit.Name = "btn_exit"
        Me.btn_exit.Size = New System.Drawing.Size(126, 37)
        Me.btn_exit.TabIndex = 16
        Me.btn_exit.Text = "EXIT"
        Me.btn_exit.UseVisualStyleBackColor = True
        '
        'btn_orderslist
        '
        Me.btn_orderslist.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_orderslist.Font = New System.Drawing.Font("Nirmala UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_orderslist.Location = New System.Drawing.Point(246, 313)
        Me.btn_orderslist.Name = "btn_orderslist"
        Me.btn_orderslist.Size = New System.Drawing.Size(153, 49)
        Me.btn_orderslist.TabIndex = 15
        Me.btn_orderslist.Text = "ORDERS"
        Me.btn_orderslist.UseVisualStyleBackColor = True
        '
        'btn_purchaseslist
        '
        Me.btn_purchaseslist.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_purchaseslist.Font = New System.Drawing.Font("Nirmala UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_purchaseslist.Location = New System.Drawing.Point(417, 313)
        Me.btn_purchaseslist.Name = "btn_purchaseslist"
        Me.btn_purchaseslist.Size = New System.Drawing.Size(153, 49)
        Me.btn_purchaseslist.TabIndex = 14
        Me.btn_purchaseslist.Text = "PURCHASES"
        Me.btn_purchaseslist.UseVisualStyleBackColor = True
        '
        'btn_staffslist
        '
        Me.btn_staffslist.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_staffslist.Font = New System.Drawing.Font("Nirmala UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_staffslist.Location = New System.Drawing.Point(417, 258)
        Me.btn_staffslist.Name = "btn_staffslist"
        Me.btn_staffslist.Size = New System.Drawing.Size(153, 49)
        Me.btn_staffslist.TabIndex = 13
        Me.btn_staffslist.Text = "STAFF"
        Me.btn_staffslist.UseVisualStyleBackColor = True
        '
        'btn_customerslist
        '
        Me.btn_customerslist.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_customerslist.Font = New System.Drawing.Font("Nirmala UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_customerslist.Location = New System.Drawing.Point(246, 258)
        Me.btn_customerslist.Name = "btn_customerslist"
        Me.btn_customerslist.Size = New System.Drawing.Size(153, 49)
        Me.btn_customerslist.TabIndex = 12
        Me.btn_customerslist.Text = "CUSTOMER"
        Me.btn_customerslist.UseVisualStyleBackColor = True
        '
        'btn_productlist
        '
        Me.btn_productlist.BackColor = System.Drawing.SystemColors.ControlLight
        Me.btn_productlist.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_productlist.Font = New System.Drawing.Font("Nirmala UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_productlist.Location = New System.Drawing.Point(417, 203)
        Me.btn_productlist.Name = "btn_productlist"
        Me.btn_productlist.Size = New System.Drawing.Size(153, 49)
        Me.btn_productlist.TabIndex = 11
        Me.btn_productlist.Text = "COOKBOOK"
        Me.btn_productlist.UseVisualStyleBackColor = False
        '
        'btn_catalog
        '
        Me.btn_catalog.BackColor = System.Drawing.SystemColors.ControlLight
        Me.btn_catalog.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_catalog.Font = New System.Drawing.Font("Nirmala UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_catalog.Location = New System.Drawing.Point(246, 203)
        Me.btn_catalog.Name = "btn_catalog"
        Me.btn_catalog.Size = New System.Drawing.Size(153, 49)
        Me.btn_catalog.TabIndex = 19
        Me.btn_catalog.Text = "VIEW BOOK CATALOG"
        Me.btn_catalog.UseVisualStyleBackColor = False
        '
        'frm_menu_a181765
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        Me.BackgroundImage = Global.prj_cookbookshop_a181765.My.Resources.Resources.img_menu
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btn_catalog)
        Me.Controls.Add(Me.btn_exit)
        Me.Controls.Add(Me.btn_orderslist)
        Me.Controls.Add(Me.btn_purchaseslist)
        Me.Controls.Add(Me.btn_staffslist)
        Me.Controls.Add(Me.btn_customerslist)
        Me.Controls.Add(Me.btn_productlist)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frm_menu_a181765"
        Me.Text = "Main Menu"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btn_exit As Button
    Friend WithEvents btn_orderslist As Button
    Friend WithEvents btn_purchaseslist As Button
    Friend WithEvents btn_staffslist As Button
    Friend WithEvents btn_customerslist As Button
    Friend WithEvents btn_productlist As Button
    Friend WithEvents btn_catalog As Button
End Class
