﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_cookbookcatalog_a181765
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_cookbookcatalog_a181765))
        Me.lbl_title = New System.Windows.Forms.Label()
        Me.lst_productID = New System.Windows.Forms.ListBox()
        Me.txt_bookname = New System.Windows.Forms.TextBox()
        Me.txt_price = New System.Windows.Forms.TextBox()
        Me.txt_author = New System.Windows.Forms.TextBox()
        Me.txt_publisher = New System.Windows.Forms.TextBox()
        Me.txt_pages = New System.Windows.Forms.TextBox()
        Me.txt_isbn = New System.Windows.Forms.TextBox()
        Me.pic_book = New System.Windows.Forms.PictureBox()
        Me.txt_productID = New System.Windows.Forms.TextBox()
        Me.lbl_bookname = New System.Windows.Forms.Label()
        Me.lbl_price = New System.Windows.Forms.Label()
        Me.lbl_author = New System.Windows.Forms.Label()
        Me.lbl_publisher = New System.Windows.Forms.Label()
        Me.lbl_pages = New System.Windows.Forms.Label()
        Me.lbl_isbn = New System.Windows.Forms.Label()
        Me.lbl_id = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btn_mainmenu = New System.Windows.Forms.Button()
        CType(Me.pic_book, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lbl_title
        '
        Me.lbl_title.AutoSize = True
        Me.lbl_title.Font = New System.Drawing.Font("Motion Picture Personal Use ", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title.Location = New System.Drawing.Point(275, 21)
        Me.lbl_title.Name = "lbl_title"
        Me.lbl_title.Size = New System.Drawing.Size(244, 55)
        Me.lbl_title.TabIndex = 0
        Me.lbl_title.Text = "Cookbook Catalog"
        '
        'lst_productID
        '
        Me.lst_productID.FormattingEnabled = True
        Me.lst_productID.Location = New System.Drawing.Point(641, 64)
        Me.lst_productID.Name = "lst_productID"
        Me.lst_productID.Size = New System.Drawing.Size(131, 329)
        Me.lst_productID.TabIndex = 1
        '
        'txt_bookname
        '
        Me.txt_bookname.BackColor = System.Drawing.Color.White
        Me.txt_bookname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_bookname.Location = New System.Drawing.Point(358, 150)
        Me.txt_bookname.Multiline = True
        Me.txt_bookname.Name = "txt_bookname"
        Me.txt_bookname.ReadOnly = True
        Me.txt_bookname.Size = New System.Drawing.Size(217, 50)
        Me.txt_bookname.TabIndex = 2
        '
        'txt_price
        '
        Me.txt_price.BackColor = System.Drawing.Color.White
        Me.txt_price.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_price.Location = New System.Drawing.Point(358, 217)
        Me.txt_price.Name = "txt_price"
        Me.txt_price.ReadOnly = True
        Me.txt_price.Size = New System.Drawing.Size(217, 21)
        Me.txt_price.TabIndex = 3
        '
        'txt_author
        '
        Me.txt_author.BackColor = System.Drawing.Color.White
        Me.txt_author.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_author.Location = New System.Drawing.Point(358, 255)
        Me.txt_author.Name = "txt_author"
        Me.txt_author.ReadOnly = True
        Me.txt_author.Size = New System.Drawing.Size(217, 21)
        Me.txt_author.TabIndex = 4
        '
        'txt_publisher
        '
        Me.txt_publisher.BackColor = System.Drawing.Color.White
        Me.txt_publisher.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_publisher.Location = New System.Drawing.Point(358, 295)
        Me.txt_publisher.Name = "txt_publisher"
        Me.txt_publisher.ReadOnly = True
        Me.txt_publisher.Size = New System.Drawing.Size(217, 21)
        Me.txt_publisher.TabIndex = 5
        '
        'txt_pages
        '
        Me.txt_pages.BackColor = System.Drawing.Color.White
        Me.txt_pages.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_pages.Location = New System.Drawing.Point(358, 333)
        Me.txt_pages.Name = "txt_pages"
        Me.txt_pages.ReadOnly = True
        Me.txt_pages.Size = New System.Drawing.Size(217, 21)
        Me.txt_pages.TabIndex = 6
        '
        'txt_isbn
        '
        Me.txt_isbn.BackColor = System.Drawing.Color.White
        Me.txt_isbn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_isbn.Location = New System.Drawing.Point(358, 372)
        Me.txt_isbn.Name = "txt_isbn"
        Me.txt_isbn.ReadOnly = True
        Me.txt_isbn.Size = New System.Drawing.Size(217, 21)
        Me.txt_isbn.TabIndex = 7
        '
        'pic_book
        '
        Me.pic_book.BackColor = System.Drawing.Color.White
        Me.pic_book.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pic_book.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_book.Location = New System.Drawing.Point(51, 150)
        Me.pic_book.Name = "pic_book"
        Me.pic_book.Size = New System.Drawing.Size(193, 242)
        Me.pic_book.TabIndex = 8
        Me.pic_book.TabStop = False
        '
        'txt_productID
        '
        Me.txt_productID.BackColor = System.Drawing.Color.White
        Me.txt_productID.Location = New System.Drawing.Point(124, 124)
        Me.txt_productID.Name = "txt_productID"
        Me.txt_productID.ReadOnly = True
        Me.txt_productID.Size = New System.Drawing.Size(96, 20)
        Me.txt_productID.TabIndex = 9
        '
        'lbl_bookname
        '
        Me.lbl_bookname.AutoSize = True
        Me.lbl_bookname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_bookname.Location = New System.Drawing.Point(315, 170)
        Me.lbl_bookname.Name = "lbl_bookname"
        Me.lbl_bookname.Size = New System.Drawing.Size(36, 15)
        Me.lbl_bookname.TabIndex = 10
        Me.lbl_bookname.Text = "Title :"
        '
        'lbl_price
        '
        Me.lbl_price.AutoSize = True
        Me.lbl_price.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_price.Location = New System.Drawing.Point(311, 220)
        Me.lbl_price.Name = "lbl_price"
        Me.lbl_price.Size = New System.Drawing.Size(41, 15)
        Me.lbl_price.TabIndex = 11
        Me.lbl_price.Text = "Price :"
        '
        'lbl_author
        '
        Me.lbl_author.AutoSize = True
        Me.lbl_author.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_author.Location = New System.Drawing.Point(304, 257)
        Me.lbl_author.Name = "lbl_author"
        Me.lbl_author.Size = New System.Drawing.Size(48, 15)
        Me.lbl_author.TabIndex = 12
        Me.lbl_author.Text = "Author :"
        '
        'lbl_publisher
        '
        Me.lbl_publisher.AutoSize = True
        Me.lbl_publisher.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_publisher.Location = New System.Drawing.Point(292, 297)
        Me.lbl_publisher.Name = "lbl_publisher"
        Me.lbl_publisher.Size = New System.Drawing.Size(65, 15)
        Me.lbl_publisher.TabIndex = 13
        Me.lbl_publisher.Text = "Publisher :"
        '
        'lbl_pages
        '
        Me.lbl_pages.AutoSize = True
        Me.lbl_pages.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_pages.Location = New System.Drawing.Point(273, 335)
        Me.lbl_pages.Name = "lbl_pages"
        Me.lbl_pages.Size = New System.Drawing.Size(83, 15)
        Me.lbl_pages.TabIndex = 14
        Me.lbl_pages.Text = "No. of Pages :"
        '
        'lbl_isbn
        '
        Me.lbl_isbn.AutoSize = True
        Me.lbl_isbn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_isbn.Location = New System.Drawing.Point(310, 374)
        Me.lbl_isbn.Name = "lbl_isbn"
        Me.lbl_isbn.Size = New System.Drawing.Size(41, 15)
        Me.lbl_isbn.TabIndex = 15
        Me.lbl_isbn.Text = "ISBN :"
        '
        'lbl_id
        '
        Me.lbl_id.AutoSize = True
        Me.lbl_id.Location = New System.Drawing.Point(66, 127)
        Me.lbl_id.Name = "lbl_id"
        Me.lbl_id.Size = New System.Drawing.Size(52, 13)
        Me.lbl_id.TabIndex = 16
        Me.lbl_id.Text = "Book ID :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(638, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(128, 30)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "Click Book ID below to" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "see the book's details"
        '
        'btn_mainmenu
        '
        Me.btn_mainmenu.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btn_mainmenu.Location = New System.Drawing.Point(21, 21)
        Me.btn_mainmenu.Name = "btn_mainmenu"
        Me.btn_mainmenu.Size = New System.Drawing.Size(90, 35)
        Me.btn_mainmenu.TabIndex = 18
        Me.btn_mainmenu.Text = "BACK"
        Me.btn_mainmenu.UseVisualStyleBackColor = False
        '
        'frm_cookbookcatalog_a181765
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(800, 428)
        Me.Controls.Add(Me.btn_mainmenu)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lbl_id)
        Me.Controls.Add(Me.lbl_isbn)
        Me.Controls.Add(Me.lbl_pages)
        Me.Controls.Add(Me.lbl_publisher)
        Me.Controls.Add(Me.lbl_author)
        Me.Controls.Add(Me.lbl_price)
        Me.Controls.Add(Me.lbl_bookname)
        Me.Controls.Add(Me.txt_productID)
        Me.Controls.Add(Me.pic_book)
        Me.Controls.Add(Me.txt_isbn)
        Me.Controls.Add(Me.txt_pages)
        Me.Controls.Add(Me.txt_publisher)
        Me.Controls.Add(Me.txt_author)
        Me.Controls.Add(Me.txt_price)
        Me.Controls.Add(Me.txt_bookname)
        Me.Controls.Add(Me.lst_productID)
        Me.Controls.Add(Me.lbl_title)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frm_cookbookcatalog_a181765"
        Me.Text = "Cookbook Catalog"
        CType(Me.pic_book, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl_title As Label
    Friend WithEvents lst_productID As ListBox
    Friend WithEvents txt_bookname As TextBox
    Friend WithEvents txt_price As TextBox
    Friend WithEvents txt_author As TextBox
    Friend WithEvents txt_publisher As TextBox
    Friend WithEvents txt_pages As TextBox
    Friend WithEvents txt_isbn As TextBox
    Friend WithEvents pic_book As PictureBox
    Friend WithEvents txt_productID As TextBox
    Friend WithEvents lbl_bookname As Label
    Friend WithEvents lbl_price As Label
    Friend WithEvents lbl_author As Label
    Friend WithEvents lbl_publisher As Label
    Friend WithEvents lbl_pages As Label
    Friend WithEvents lbl_isbn As Label
    Friend WithEvents lbl_id As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btn_mainmenu As Button
End Class
