﻿Public Class frm_purchaseslist_a181765
    Private Sub frm_purchaseslist_a181765_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim mysql As String = "SELECT TBL_PURCHASES_A181765.FLD_ORDER_ID, TBL_PURCHASES_A181765.FLD_CUST_ID, TBL_CUSTOMERS_A181765.FLD_CUST_NAME, TBL_PURCHASES_A181765.FLD_PRODUCT_ID, TBL_PRODUCTS_A181765.FLD_PRODUCT_NAME, TBL_PURCHASES_A181765.FLD_PRICE, TBL_PURCHASES_A181765.FLD_QUANTITY" _
                              & " FROM TBL_CUSTOMERS_A181765 INNER JOIN (TBL_PRODUCTS_A181765 INNER JOIN TBL_PURCHASES_A181765 ON TBL_PRODUCTS_A181765.FLD_PRODUCT_ID = TBL_PURCHASES_A181765.FLD_PRODUCT_ID) ON TBL_CUSTOMERS_A181765.FLD_CUST_ID = TBL_PURCHASES_A181765.FLD_CUST_ID"

        Dim mydatatable As New DataTable

        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)

        myreader.Fill(mydatatable)

        grd_purchases.DataSource = mydatatable

        grd_purchases.Columns(0).HeaderText = "Order ID"
        grd_purchases.Columns(1).HeaderText = "Customer ID"
        grd_purchases.Columns(2).HeaderText = "Customer Name"
        grd_purchases.Columns(3).HeaderText = "Book ID"
        grd_purchases.Columns(4).HeaderText = "Book Title"
        grd_purchases.Columns(5).HeaderText = "Price/unit"
        grd_purchases.Columns(6).HeaderText = "Quantity"

        refresh_grid()

    End Sub

    Private Sub refresh_grid()

        Dim mysql As String = "SELECT TBL_PURCHASES_A181765.FLD_ORDER_ID, TBL_PURCHASES_A181765.FLD_CUST_ID, TBL_CUSTOMERS_A181765.FLD_CUST_NAME, TBL_PURCHASES_A181765.FLD_PRODUCT_ID, TBL_PRODUCTS_A181765.FLD_PRODUCT_NAME, TBL_PURCHASES_A181765.FLD_PRICE, TBL_PURCHASES_A181765.FLD_QUANTITY" _
                              & " FROM TBL_CUSTOMERS_A181765 INNER JOIN (TBL_PRODUCTS_A181765 INNER JOIN TBL_PURCHASES_A181765 ON TBL_PRODUCTS_A181765.FLD_PRODUCT_ID = TBL_PURCHASES_A181765.FLD_PRODUCT_ID) ON TBL_CUSTOMERS_A181765.FLD_CUST_ID = TBL_PURCHASES_A181765.FLD_CUST_ID"

        Dim mydatatable As New DataTable

        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)

        myreader.Fill(mydatatable)

        grd_purchases.DataSource = mydatatable

    End Sub

    Private Sub btn_back_Click(sender As Object, e As EventArgs) Handles btn_back.Click

        frm_menu_a181765.Show()
        Me.Hide()

    End Sub
End Class