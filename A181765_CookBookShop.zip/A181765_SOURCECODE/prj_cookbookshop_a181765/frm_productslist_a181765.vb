﻿Public Class frm_productslist_a181765
    Private Sub frm_productslist_a181765_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim mysql As String = "SELECT * FROM TBL_PRODUCTS_A181765"

        Dim mydatatable As New DataTable

        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)

        myreader.Fill(mydatatable)

        grd_products.DataSource = mydatatable

        grd_products.Columns(0).HeaderText = "Book ID"
        grd_products.Columns(1).HeaderText = "Book Title"
        grd_products.Columns(2).HeaderText = "Price (RM)"
        grd_products.Columns(3).HeaderText = "Author"
        grd_products.Columns(4).HeaderText = "Publisher"
        grd_products.Columns(5).HeaderText = "Number of Pages"
        grd_products.Columns(6).HeaderText = "ISBN"

        refresh_grid()

    End Sub
    Private Sub refresh_grid()

        Dim mysql As String = "SELECT * FROM TBL_PRODUCTS_A181765"

        Dim mydatatable As New DataTable

        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)

        myreader.Fill(mydatatable)

        grd_products.DataSource = mydatatable

    End Sub
    Private Sub btn_back_Click(sender As Object, e As EventArgs) Handles btn_back.Click

        frm_menu_a181765.Show()
        Me.Hide()

    End Sub

    Private Sub btn_addproduct_Click(sender As Object, e As EventArgs) Handles btn_addproduct.Click

        frm_insertproducts_a181765.Show()
        Me.Hide()

    End Sub

    Private Sub btn_editproduct_Click(sender As Object, e As EventArgs) Handles btn_editproduct.Click

        frm_updateproducts_a181765.Show()
        Me.Hide()

    End Sub
End Class